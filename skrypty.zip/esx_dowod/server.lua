ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
local katb = false
local kata = false
local katc = false
local jestb = 'nil'
function getIdentity(source)
	local identifier = GetPlayerIdentifiers(source)[1]
	local result = MySQL.Sync.fetchAll("SELECT * FROM users WHERE identifier = @identifier", {['@identifier'] = identifier})
	if result[1] ~= nil then
		local identity = result[1]

		return {
			identifier = identity['identifier'],
			firstname = identity['firstname'],
			lastname = identity['lastname'],
			name = identity['name'],
			dateofbirth = identity['dateofbirth'],
			sex = identity['sex'],
			height = identity['height'],
            job = identity['job'],
			phone_number = identity['phone_number']
                        
		}
	else
		return nil
	end 
end
function getlicenseB(source)
	local identifier = GetPlayerIdentifiers(source)[1]

local result = MySQL.Sync.fetchAll("SELECT * FROM user_licenses WHERE type = @type and owner = @owner",
    {
      ['@owner']   = identifier,
      ['@type'] = 'drive'

    })


	if result[1] ~= nil then

katb = true
jestb = '~h~~g~B ~s~'
	else
		jestb = '~h~~r~B ~s~'
	end
end
function getlicenseA(source)
	local identifier = GetPlayerIdentifiers(source)[1]

local result = MySQL.Sync.fetchAll("SELECT * FROM user_licenses WHERE type = @type and owner = @owner",
    {
      ['@owner']   = identifier,
      ['@type'] = 'drive_bike'

    })


	if result[1] ~= nil then

kata = true
jesta = '~h~~g~A ~s~'
	else
				jesta = '~h~~r~A ~s~'
	end
end
function getlicenseC(source)
	local identifier = GetPlayerIdentifiers(source)[1]

local result = MySQL.Sync.fetchAll("SELECT * FROM user_licenses WHERE type = @type and owner = @owner",
    {
      ['@owner']   = identifier,
      ['@type'] = 'drive_truck'

    })


	if result[1] ~= nil then

katc = true
jestc = '~h~~g~C~n~ ~s~'
	else
				jestc = '~h~~r~C ~n~~s~'
	end
end

function getlicenseW(source)
	local identifier = GetPlayerIdentifiers(source)[1]

local result = MySQL.Sync.fetchAll("SELECT * FROM user_licenses WHERE type = @type and owner = @owner",
    {
      ['@owner']   = identifier,
      ['@type'] = 'weapon'

    })


	if result[1] ~= nil then


jestw = '~g~Tak~n~ ~s~'
	else
				jestw = '~r~Nie~n~ ~s~'
	end
end
RegisterServerEvent('esx_dowod:wizytowka')
AddEventHandler('esx_dowod:wizytowka', function(source)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)


          local name = getIdentity(source)



	TriggerClientEvent('esx:dowod_wiz', -1,_source,  '~h~'..name.firstname..' ','Numer Telefonu: '..name.phone_number)

end)
RegisterServerEvent('esx_dowod:pokaz')
AddEventHandler('esx_dowod:pokaz', function(source)
			print("Działam")
		  local _source = source
		  local xPlayer = ESX.GetPlayerFromId(_source)

          local lickaB = getlicenseB(source)
          local lickaA = getlicenseA(source)
          local lickaC = getlicenseC(source)
          local lickaW = getlicenseW(source)
          local name = getIdentity(source)
		  if name.job == ambulance then 
			name.job = Medyk
			end
		  



	TriggerClientEvent('esx:dowod_pokazdowod', -1,_source,  '~h~'..name.firstname..' '..name.lastname,name.dateofbirth,'Licencja Na Bron: '..jestw.. 'Kat: '..jestb..''..jesta..''..jestc)
--TriggerClientEvent('esx:dowod_pokaz', _source)
	--TriggerClientEvent('esx:dowod_pokazdowod', target, '~h~'..name.firstname..' '..name.lastname,name.dateofbirth,'Licencja Na Bron: '..jestw.. 'Prawo Jazdy Kat: '..jesta..' '..jestb..' '..jestc)
end)