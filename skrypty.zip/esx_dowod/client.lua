
ESX                           = nil
local PlayerData                = {}

Citizen.CreateThread(function()

	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  PlayerData.job = job
end)



function ShowAdvancedNotification(title, subject, msg, icon, iconType)


	SetNotificationTextEntry('STRING')
	AddTextComponentString(msg)
	SetNotificationMessage(icon, icon, false, iconType, title, subject)
	DrawNotification(false, false)

end
RegisterNetEvent('esx:dowod_pokazdowod')
AddEventHandler('esx:dowod_pokazdowod', function(id, imie, data, dodatek)


  --local praca = PlayerData.job.label

  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  local mugshot, mugshotStr = ESX.Game.GetPedMugshot(GetPlayerPed(pid))
  if pid == myId then
SetNotificationBackgroundColor(200)
ShowAdvancedNotification(imie, data, dodatek, mugshotStr, 8)

  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 19.999 then
 SetNotificationBackgroundColor(200)
 ShowAdvancedNotification(imie, data, dodatek, mugshotStr, 8)

  end
  
  UnregisterPedheadshot(mugshot)

end)
RegisterNetEvent('esx:dowod_pokazdowod2')
AddEventHandler('esx:dowod_pokazdowod2', function(id, imie, data, dodatek)


  --local praca = PlayerData.job.label
	if PlayerData.job ~= nil and PlayerData.job.name == 'police' then
  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  local mugshot, mugshotStr = ESX.Game.GetPedMugshot(GetPlayerPed(pid))
SetNotificationBackgroundColor(200)
ShowAdvancedNotification(imie, data, dodatek, mugshotStr, 8)
	end
  
  UnregisterPedheadshot(mugshot)

end)

RegisterNetEvent('esx:dowod_wiz')
AddEventHandler('esx:dowod_wiz', function(id, imie, dodatek)



  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  local mugshot, mugshotStr = ESX.Game.GetPedMugshot(GetPlayerPed(pid))
  if pid == myId then
SetNotificationBackgroundColor(190)
ShowAdvancedNotification(imie, '', dodatek, mugshotStr, 8)

  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 19.999 then
 SetNotificationBackgroundColor(190)  
 ShowAdvancedNotification(imie, '', dodatek, mugshotStr, 8)

  end
  
  UnregisterPedheadshot(mugshot)

end)