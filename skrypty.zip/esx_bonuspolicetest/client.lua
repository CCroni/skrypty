local Keys = {
	["ESC"] = 322, ["BACKSPACE"] = 177, ["E"] = 38, ["ENTER"] = 18,	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173
}

ESX                           = nil
local PlayerData                = {}
local menuIsShowed 				 = false
local hasAlreadyEnteredMarker 	 = false
local hasAlreadyEnteredMarkerr 	 = false
local lastZone 					 = nil
                        local powiadomienia = true

Citizen.CreateThread(function()

	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

end)


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	PlayerData.job = job
end)


Citizen.CreateThread(function()
	while true do
		Citizen.Wait(5)
		local coords = GetEntityCoords(GetPlayerPed(-1))
if PlayerData.job ~= nil and (PlayerData.job.name == 'police' or PlayerData.job.name == 'offpolice') then

			if(GetDistanceBetweenCoords(coords, 454.51, -987.13, 25.7, true) < 100.0) then
				DrawMarker(23, 454.51, -987.13, 25.7, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 3.0, 3.0, 2.0, 100, 100, 204, 100, false, true, 2, false, false, false, false)
			
			end
 		end
	end
end)



Citizen.CreateThread(function()
	while true do
		
		Wait(0)
		

			local coords      = GetEntityCoords(GetPlayerPed(-1))
			local isInMarker  = false
			local currentZone = nil

if PlayerData.job ~= nil and (PlayerData.job.name == 'police' or PlayerData.job.name == 'offpolice') then

			
				if(GetDistanceBetweenCoords(coords, 454.51, -987.13, 25.7, true) < 3.0)  then
					isInMarker  = true
if powiadomienia then
         ESX.ShowHelpNotification("Wciśnij ~INPUT_CONTEXT~")
end
if IsControlJustReleased(0, Keys['E']) then
powiadomienia = false
                                        TriggerServerEvent('esx_bonuspolice:magazynuj', GetPlayerPed(-1))
					end

				end
			
			if(GetDistanceBetweenCoords(coords, 454.51, -987.13, 25.7, true) > 3.0) then
powiadomienia = true
end
			
end





	end
end)

RegisterNetEvent('esx_bonuspolice:brak')
AddEventHandler('esx_bonuspolice:brak', function()

ESX.ShowNotification("Nie masz nic do oddania")

end)