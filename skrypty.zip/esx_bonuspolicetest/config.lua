Config                            = {}


Config.Coke = 1800	--
Config.Weed = 800	--
Config.Meth = 1400--  
Config.Opium = 1100 -- 
Config.Brudna = 0.25 -- 



