ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)



RegisterServerEvent('esx_bonuspolice:magazynuj') 
AddEventHandler('esx_bonuspolice:magazynuj', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
local coke = xPlayer.getInventoryItem('coke_pooch').count
local weed = xPlayer.getInventoryItem('weed_pooch').count
local meth = xPlayer.getInventoryItem('meth_pooch').count
local opium = xPlayer.getInventoryItem('opium_pooch').count
	local accountMoney = 0
	accountMoney = xPlayer.getAccount('black_money').money


if coke > 0 then
	xPlayer.removeInventoryItem('coke_pooch', coke)
		xPlayer.addMoney(Config.Coke*coke)
TriggerClientEvent('chatMessage', source, "Magazyn", {255, 0, 0}, "^2Oddales ^4"..coke.." ^2Kokainy do magazynu. Bonus:^4"..Config.Coke*coke.."$")

 end
if weed > 0 then
	xPlayer.removeInventoryItem('weed_pooch', weed)
		xPlayer.addMoney(Config.Weed*weed)
TriggerClientEvent('chatMessage', source, "Magazyn", {255, 0, 0}, "^2Oddales ^4"..weed.." ^2Marihuany do magazynu. Bonus:^4"..Config.Weed*weed.."$")
 end
if meth > 0 then
	xPlayer.removeInventoryItem('meth_pooch', meth)
		xPlayer.addMoney(Config.Meth*meth)
TriggerClientEvent('chatMessage', source, "Magazyn", {255, 0, 0}, "^2Oddales ^4"..meth.." ^2Metamfetaminy do magazynu. Bonus:^4"..Config.Meth*meth.."$")
 end
if opium > 0 then
	xPlayer.removeInventoryItem('opium_pooch', opium)
		xPlayer.addMoney(Config.Opium*opium)
TriggerClientEvent('chatMessage', source, "Magazyn", {255, 0, 0}, "^2Oddales ^4"..opium.." ^2Opium do magazynu. Bonus:^4"..Config.Opium*opium.."$")
end
if accountMoney > 0 then
		xPlayer.removeAccountMoney('black_money', accountMoney)
		xPlayer.addMoney(round(Config.Brudna*accountMoney))
TriggerClientEvent('chatMessage', source, "Magazyn", {255, 0, 0}, "^2Oddales ^4"..accountMoney.."$ ^2brudnej kasy do magazynu. Bonus:^4"..round(Config.Brudna*accountMoney).."$")
 end



if coke == 0 and weed == 0 and meth == 0 and opium == 0 and accountmoney == 0 then

TriggerClientEvent('esx_bonuspolice:brak', source)
end
end)

function round(n)
    return n % 1 >= 0.5 and math.ceil(n) or math.floor(n)
end