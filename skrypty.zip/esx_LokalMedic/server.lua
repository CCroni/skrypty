--  Made By Zeaqy --

ESX                = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('esx-Zeaqy-ER:pay')
AddEventHandler('esx-Zeaqy-ER:pay', function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local society = 'society_ambulance'
    
	if(xPlayer.getMoney() >= 3500) then
		xPlayer.removeMoney(3500)
    end
	TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
		account.addMoney(3500)
end)
end)

ESX.RegisterServerCallback('esx-Zeaqy-ER:money', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local money    = xPlayer.getMoney(source)
    if money >= 3500 then
     cb(true)
    else
     cb(false)
     TriggerClientEvent("pNotify:SetQueueMax", -1, hej, 4)
            TriggerClientEvent("pNotify:SendNotification", source, {
                        text = "Nie posiadasz tyle pieniędzy!",
                        type = "warning",
                        progressBar = false,
                        queue = "zeaq",
                        timeout = 2000,
                        layout = "bottomCenter"
                })
    end
end)
                
function sendNotification(xSource, message, messageType, messageTimeout)
    TriggerClientEvent("pNotify:SendNotification", xSource, {
        text = message,
        type = messageType,
        queue = "zeaq",
        timeout = messageTimeout,
        layout = "bottomCenter"
    })
end

RegisterServerEvent('esx-Zeaqy-ER:check')
AddEventHandler('esx-Zeaqy-ER:check', function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local xPlayers = ESX.GetPlayers()

    local ambulance = 0
        for i=1, #xPlayers, 1 do
            local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
            if xPlayer.job.name == 'ambulance' then
                    ambulance = ambulance + 1
            end
        end
        if ambulance == 0 then
            TriggerClientEvent('esx-Zeaqy-ER:Last', _source)
    else
        sendNotification(_source, 'Aktualnie są Medycy na Służbie!', 'error', 2500)
    end
end)
