--  Made By Zeaqy --

client_scripts {
    "client.lua"
}

server_scripts{
    "server.lua",
    '@mysql-async/lib/MySQL.lua',
}

dependencies {
	'esx_addonaccount',
	'esx_addoninventory'
}