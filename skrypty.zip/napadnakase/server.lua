--Written by Tościk#9715

ESX = nil

TriggerEvent('esx:getSharedObject', function(obj)
	ESX = obj
end)

RegisterServerEvent('tost:zgarnijsiano')
AddEventHandler('tost:zgarnijsiano', function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local Ilosc = math.random(1500,2500) --Mozna zgarnac od 500 do max 1800$ za kase fiskalna
	TriggerClientEvent('esx:showNotification', source, '~y~Zabierasz ~g~'..Ilosc..'$~y~ z kasy fiskalnej.')
	TriggerClientEvent('esx:showNotification', source, '~y~Następną kasę możesz obrabować za 90 sekund.')
    xPlayer.addMoney(Ilosc)
	Wait(500)
end)


RegisterServerEvent('tost:zawiadompsy')
AddEventHandler('tost:zawiadompsy', function(x, y, z) 
    TriggerClientEvent('tost:infodlalspd', -1, x, y, z)
end)

RegisterServerEvent('tost:SprawdzPolicje')
AddEventHandler('tost:SprawdzPolicje', function() 
    local copsOnDuty = 0

    local Players = ESX.GetPlayers()

    for i = 1, #Players do
        local xPlayer = ESX.GetPlayerFromId(Players[i])

        if xPlayer["job"]["name"] == "police" then
            copsOnDuty = copsOnDuty + 1
        end
    end

    if copsOnDuty >= 1 then
        TriggerClientEvent("tost:PozwolNapad", source)
    else
        TriggerClientEvent('esx:showNotification', source, '~y~Potrzeba przynajmniej jednego policjanta na służbie aby to wykonać.')
    end
end)