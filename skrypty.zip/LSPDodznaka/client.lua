RegisterNetEvent('gln:DisplayPlate')
AddEventHandler('gln:DisplayPlate', function(id, playerName, job)
  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  if pid == myId then
	TriggerEvent("pNotify:SendNotification", { --# To co widzi osoba wpisująca komendę 
          text = "<font style='font-size: 20px'><div style='min-width: 350px; min-height: 514px; background-image: url(https://i.imgur.com/WN600ph.png); opacity: 1.0; background-size: contain; background-position: center;  background-repeat: no-repeat;'><div style='opacity: 1.0; position: absolute; top: 178px; left: 21px; color:#E2E3E5'><B>Imię i nazwisko:</b> <BR>" ..playerName.." <BR><BR><B>Stopień:</B> ".. job .. "<BR></div>",
          type = "info",
          queue = "global",
          timeout = 10000,
          layout = "centerLeft" --# Tutaj możecie sobie zmienić w jakim miejscu odznaka ma się pokazywać, czy z lewej czy z prawej.
        }) 
  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 3.9999 then
       TriggerEvent("pNotify:SendNotification", { --# To co widzi osoba stojąca obok
          text = "<font style='font-size: 20px'><div style='min-width: 350px; min-height: 514px; background-image: url(https://i.imgur.com/WN600ph.png); opacity: 1.0; background-size: contain; background-position: center;  background-repeat: no-repeat;'><div style='position: absolute; opacity: 1.0; top: 178px; left: 21px; color:#E2E3E5'><B>Imię i nazwisko:</b> <BR>" ..playerName.." <BR><BR><B>Stopień:</B> ".. job .. "<BR></div>",
          type = "info",
          queue = "global",
          timeout = 10000,
          layout = "centerLeft" --# Tutaj możecie sobie zmienić w jakim miejscu odznaka ma się pokazywać, czy z lewej czy z prawej.
        })
  end
end)

--# Animacja użyte do zrobienia skryptu oraz prop odznaki

local plateModel = "prop_fib_badge"
local animDict = "missfbi_s4mop"
local animName = "swipe_card"
local plate_net = nil

RegisterNetEvent("gln:plateanim")
AddEventHandler("gln:plateanim", function()

  RequestModel(GetHashKey(plateModel))
  while not HasModelLoaded(GetHashKey(plateModel)) do
    Citizen.Wait(100)
  end

  RequestAnimDict(animDict)
  while not HasAnimDictLoaded(animDict) do
    Citizen.Wait(100)
  end

  local plyCoords = GetOffsetFromEntityInWorldCoords(GetPlayerPed(PlayerId()), 0.0, 0.0, -5.0)
  local platespawned = CreateObject(GetHashKey(plateModel), plyCoords.x, plyCoords.y, plyCoords.z, 1, 1, 1)
  Citizen.Wait(1000)
  local netid = ObjToNet(platespawned)
  SetNetworkIdExistsOnAllMachines(netid, true)
  SetNetworkIdCanMigrate(netid, false)
  TaskPlayAnim(GetPlayerPed(PlayerId()), 1.0, -1, -1, 50, 0, 0, 0, 0)
  TaskPlayAnim(GetPlayerPed(PlayerId()), animDict, animName, 1.0, 1.0, -1, 50, 0, 0, 0, 0)
  Citizen.Wait(800)
  AttachEntityToEntity(platespawned, GetPlayerPed(PlayerId()), GetPedBoneIndex(GetPlayerPed(PlayerId()), 28422), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1, 1, 0, 1, 0, 1)
  plate_net = netid
  Citizen.Wait(3000)
  ClearPedSecondaryTask(GetPlayerPed(PlayerId()))
  DetachEntity(NetToObj(plate_net), 1, 1)
  DeleteEntity(NetToObj(plate_net))
  plate_net = nil
end)
