
ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

function getIdentity(source)
	local identifier = GetPlayerIdentifiers(source)[1]
	local result = MySQL.Sync.fetchAll("SELECT * FROM users WHERE identifier = @identifier", {['@identifier'] = identifier})
	if result[1] ~= nil then
		local identity = result[1]

		return {
			identifier = identity['identifier'],
			firstname = identity['firstname'],
			lastname = identity['lastname'],
			dateofbirth = identity['dateofbirth'],	
			sex = identity['sex'],
			height = identity['height'],
			job = identity['job']
		}
	else
		return nil
	end
end

function getJobName(jobname)
	local result = MySQL.Sync.fetchAll("SELECT * FROM jobs WHERE name = @identifier", {['@identifier'] = jobname})
	if result[1] ~= nil then
		local identity = result[1]

		return {
			name = identity['name'],
			label = identity['label'],
		}
	else
		return nil
	end
end

TriggerEvent('es:addCommand', 'odznaka', function(source, args, user) --# Komenda, która wywołuje pokazanie się legityki/odznaki
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local name = getIdentity(_source)
	local rname = name.firstname.. " " ..name.lastname
	if xPlayer.job.name == "police" then --# Praca jaką musi mieć oponent aby komenda zadziałała
		TriggerClientEvent("gln:plateanim", _source)
		TriggerClientEvent("gln:DisplayPlate", -1, _source, rname, xPlayer.job.grade_label)
	else
		TriggerClientEvent('esx:showNotification', _source, '~r~Nie jesteś policjantem!  🚓')
	end
end)


RegisterNetEvent('gln:ShowPlate')
AddEventHandler('gln:ShowPlate', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local name = getIdentity(_source)
	local rname = name.firstname.. " " ..name.lastname
	if xPlayer.job.name == "police" then --# Praca jaką musi mieć oponent aby komenda zadziałała
		TriggerClientEvent("gln:plateanim", _source)
		TriggerClientEvent("gln:DisplayPlate", -1, _source, rname, xPlayer.job.grade_label)
	else
		TriggerClientEvent('esx:showNotification', _source, '~r~Nie jesteś policjantem!  🚓') --# Notyfikacja, które wyświetla się jeśli ktoś nie ma nadanej pracy 
	end
end)