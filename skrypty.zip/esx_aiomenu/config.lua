EngineStartWhenEnteringVehicle = true
FRFuelSupport = false