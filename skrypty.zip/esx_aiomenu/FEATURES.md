## Features

* Direct Interaction With ESX Identity to delete, change, and create new characters without the need for commands.
* Display Your Phone Number In Chat
* Display Your ID To People In Chat
* Toggle Your Vehicles Engine On/Off
* Toggle Vehicle Locks
* Toggle Each Vehicle Door Open/Closed
* Toggle Windows Up/Down
* Toggle Hood
* Toggle Trunk





## WORK IN PROGRESS
* Open Inventory
* Open Invoices
* Set Voice
* Open Animations
* Toggle Phone Menu
* Job Actions