Config                            = {}

Config.Center = {x= -255.94, y= -983.93, z= 30.21}
Config.Percent = 50 -- Od 1 - 100 procent, przy 10 policja widzi rzadko przy 90 widzi 90%, im wiecej tym czesciej widzi informacje ze ktos sprzedaje
Config.PoliceCount = 2 -- Ile policji potrzebne aby moc sprzedawac narko
Config.Dist = 2500 -- Odleglosc od miasta



--JESLI DOLNA GRANICA BEDZIE WIEKSZA OD GORNEJ SKRYPT MOZE SIE WYSYPAC
Config.WeedPriceA = 800	-- Dolna granica ceny ziola
Config.WeedPriceB = 1000	-- Gorna granica ceny
Config.MethPriceA = 1400--  Dolna granica ceny
Config.MethPriceB = 1700 -- Gorna granica 
Config.CokePriceA = 1800	-- Dolna
Config.CokePriceB = 2300	-- Gorna
Config.OpiuPriceA = 1100	-- Dolna
Config.OpiuPriceB = 1300	-- Gorna


