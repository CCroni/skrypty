--Written by Tościk#9715

ESX = nil

TriggerEvent('esx:getSharedObject', function(obj)
	ESX = obj
end)

------------------------------------------
------------------------------------------

RegisterServerEvent('tost:zbierzroslinke')
AddEventHandler('tost:zbierzroslinke', function(rodzaj)
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
		if rodzaj == 10 then
		xPlayer.removeInventoryItem('water', 1)
		xPlayer.removeInventoryItem('nasionko', 1)
		Wait(1500)
		end
		--
		if rodzaj == 11 then
		xPlayer.removeInventoryItem('water', 1)
		xPlayer.removeInventoryItem('nasiono2', 1)
		Wait(1500)
		end
		--
		if rodzaj == 12 then
		xPlayer.removeInventoryItem('water', 1)
		xPlayer.removeInventoryItem('nasiono3', 1)
		Wait(1500)
		end
		----
		
	if rodzaj == 1 then
	local ilosc = math.random(2,5) --minimalna i maxymalna ilosc zebranych lisci
	TriggerClientEvent('esx:showNotification', source, '~g~Zbierasz ~y~'..ilosc.. ' ~g~liście.')
    xPlayer.addInventoryItem('liscie1', ilosc) --gracz otrzymuje przedmiot liscie
	
	elseif rodzaj == 2 then
		local gnije = math.random(1,100) --25% na to ze roślina zgnije i nic nie otrzymamy
	
		if gnije >= 75 then
		local ilosc = math.random(2,5) --minimalna i maxymalna ilosc zebranych lisci
		TriggerClientEvent('esx:showNotification', source, '~g~Zbierasz ~y~'..ilosc.. ' ~g~liście.')
		xPlayer.addInventoryItem('liscie2', ilosc) --gracz otrzymuje przedmiot liscie
		else
		TriggerClientEvent('esx:showNotification', source, '~r~Roślina zgniła i nic nie dostajesz.')
		end
		
	elseif rodzaj == 3 then
		local gnije = math.random(0,1) --50% szans na to ze roślina zgnije i nic nie otrzymamy
	
		if gnije == 0 then
		local ilosc = math.random(2,5) --minimalna i maxymalna ilosc zebranych lisci
		TriggerClientEvent('esx:showNotification', source, '~g~Zbierasz ~y~'..ilosc.. ' ~g~liście.')
		xPlayer.addInventoryItem('liscie3', ilosc) --gracz otrzymuje przedmiot liscie
		else
		TriggerClientEvent('esx:showNotification', source, '~r~Roślina zgniła i nic nie dostajesz.')
		end
	end
	Wait(500)
end)

--dla konio
RegisterServerEvent('tostkrzaki:przerobnarkoty')
AddEventHandler('tostkrzaki:przerobnarkoty', function(rodzaj)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local liscieKonopi = xPlayer.getInventoryItem('liscie1').count
	local liscieMakowca = xPlayer.getInventoryItem('liscie2').count
	local liscieKoki = xPlayer.getInventoryItem('liscie3').count

if rodzaj == 'konopia' then
	if liscieKonopi > 0 then
	xPlayer.removeInventoryItem('liscie1', 5)
	xPlayer.addInventoryItem('weed_pooch', 1) 
	end
end

if rodzaj == 'makowiec' then
	if liscieMakowca > 0 then
	xPlayer.removeInventoryItem('liscie2', 5)
	xPlayer.addInventoryItem('opium_pooch', 1) 
	end
end

if rodzaj == 'koka' then
	if liscieKoki > 0 then
	xPlayer.removeInventoryItem('liscie3', 5)
	xPlayer.addInventoryItem('coke_pooch', 1) 
	end
end


end)

