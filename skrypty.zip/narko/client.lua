-------Written by Tościk#9715------
-------------KONFIG----------------



local roslina1Nazwa = '<b><font size=4>Nasiona konopi</b>'	--nazwa pierwszej rośliny w menu do sadzenia
local roslina2Nazwa = '<b><font size=4>Nasiona opium</b>'	--nazwa drugiej rośliny w menu do sadzenia
local roslina3Nazwa = '<b><font size=4>Nasiona koki</b>'	--nazwa trzeciej rośliny w menu do sadzenia


local MiejsceSadzenia = {  --koordynaty do sadzenia roslinek
    {x = 1058.0880126954, y = -3189.0397949218, z = -39.131740570068},  
    {x = 1058.0911865234, y = -3190.8657226562, z = -39.143817901612},
    {x = 1056.412109375, y = -3190.9497070312, z = -39.116249084472},
    {x = 1054.6392822266, y = -3190.6184082032, z = -39.141010284424}, 
    {x = 1054.8505859375, y = -3189.0529785156, z = -39.142234802246},
    {x = 1056.4029541016, y = -3189.2473144532, z = -39.037799835206},
    {x = 1057.5812988282, y = -3197.2214355468, z = -39.12981414795}, 
    {x = 1061.2459716796, y = -3197.6506347656, z = -39.143913269042},
    {x = 1062.7487792968, y = -3197.6882324218, z = -39.141033172608},
    {x = 1064.4663085938, y = -3197.3818359375, z = -39.127323150634}, 
    {x = 1064.564453125, y = -3198.9597167968, z = -39.135135650634},
    {x = 1063.0821533204, y = -3199.3820800782, z = -39.121391296386},
    {x = 1061.318359375, y = -3199.6391601562, z = -39.149047851562}, 
    {x = 1056.1300048828, y = -3204.2585449218, z = -39.042366027832},
    {x = 1055.7010498046, y = -3205.712890625, z = -39.124725341796},
    {x = 1055.8122558594, y = -3207.3786621094, z = -39.044357299804},
    {x = 1057.5200195312, y = -3207.4057617188, z = -39.045265197754}, 
    {x = 1057.4055175782, y = -3205.9438476562, z = -39.12928390503},
    {x = 1057.7727050782, y = -3204.5239257812, z = -38.97587966919},
    {x = 1059.4382324218, y = -3204.439453125, z = -39.024700164794}, 
    {x = 1059.2629394532, y = -3206.3359375, z = -39.129501342774},
    {x = 1059.0417480468, y = -3207.4904785156, z = -39.04768371582},
}
local SprzedazKonopi = { x = 2224.0078125, y = 5577.203125, z = 53.838802337646} --do przerabiania konopi, pomylilem sie i nazwalem sprzedaz
local SprzedazMakowca = { x = 1006.0873413086, y = -3195.439453125, z = -38.993167877198}--do przerabiania makowca, pomylilem sie i nazwalem sprzedaz
local SprzedazKoki = { x = 1091.7147216796, y = -3194.2348632812, z = -38.993469238282}--do przerabiania koki, pomylilem sie i nazwalem sprzedaz
---------------------------------------------Ponizej lepiej nie ruszac :)-------------------------
local Keys = {["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
  ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
  ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
  ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70, 
  ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
  ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
  ["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
}
---------
ESX = nil

local playerCoords = GetEntityCoords(GetPlayerPed(-1))
local Oczekiwanie = 5
local posadzone = 0
local obiekt
local wzrost = 0
local procent = 0
local wyborRosliny = 0
local nasionoKonopi = 0
local nasionoMakowca = 0
local nasionoKoki = 0
local liscieKonopi = 0
local liscieMakowca = 0
local liscieKoki = 0

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end
	PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
end)
--


Citizen.CreateThread(function()
    while true do
	Citizen.Wait(2500)

for k in pairs(MiejsceSadzenia) do	
	local pedCoords = GetEntityCoords(PlayerPedId())
    local dist = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, MiejsceSadzenia[k].x, MiejsceSadzenia[k].y, MiejsceSadzenia[k].z)
		
if dist <= 25.0 then
	local inventory = ESX.GetPlayerData().inventory
	for i=1, #inventory, 1 do
		if inventory[i].name == 'nasionko' then
		nasionoKonopi = inventory[i].count
		end
		if inventory[i].name == 'nasiono2' then
		nasionoMakowca = inventory[i].count
		end
		if inventory[i].name == 'nasiono3' then
		nasionoKoki = inventory[i].count
		end
	end
else
Citizen.Wait(4000)
end
	
	
end	
end
end)
--
Citizen.CreateThread(function()
    while true do
    Citizen.Wait(Oczekiwanie)
 for k in pairs(MiejsceSadzenia) do
 
        local pedCoords = GetEntityCoords(PlayerPedId())
        local dist = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, MiejsceSadzenia[k].x, MiejsceSadzenia[k].y, MiejsceSadzenia[k].z)
		
		if dist <= 15.0 and posadzone == 0 then
			if (nasionoKonopi > 0) or (nasionoMakowca > 0) or (nasionoKoki > 0) then
			DrawMarker(1, MiejsceSadzenia[k].x, MiejsceSadzenia[k].y, MiejsceSadzenia[k].z-1.2, 0, 0, 0, 0, 0, 0, 1.001, 1.0001, 0.4001, 255, 255, 0, 200, 0, 0, 0, 0)
			else
			Citizen.Wait(1000)
			end
		elseif dist <= 2.0 and posadzone == 1 then
		DrawMarker(0, MiejsceSadzenia[k].x, MiejsceSadzenia[k].y, MiejsceSadzenia[k].z+1.5, 0, 0, 0, 0, 0, 0, 0.501, 0.5001, 0.5001, 0, 250, 0, 200, 1, 0, 0, 0)
		end
		
		
		if dist <= 1.5 and posadzone == 0 then
			if (nasionoKonopi > 0) or (nasionoMakowca > 0) or (nasionoKoki > 0) then
			DrawText3D(MiejsceSadzenia[k].x, MiejsceSadzenia[k].y, MiejsceSadzenia[k].z,'~g~[E] ~y~Aby posadzić')
			end
		elseif dist <= 1.5 and posadzone == 1 then
		DrawText3D(MiejsceSadzenia[k].x, MiejsceSadzenia[k].y, MiejsceSadzenia[k].z,'~g~[E] ~y~Aby zebrać')
		end
		
	if dist <= 1.5 then
	
        if IsControlJustPressed(0, Keys['E']) and posadzone == 0 then
				local inventory = ESX.GetPlayerData().inventory
				local count = 0
				for i=1, #inventory, 1 do
					if inventory[i].name == 'water' then
					count = inventory[i].count
					end
				end
				
			if(count > 0) then
				local pedCoords = GetEntityCoords(PlayerPedId())
				local objectId = GetClosestObjectOfType(pedCoords, 2.5, GetHashKey("prop_plant_int_03c"), false)
				local objectId2 = GetClosestObjectOfType(pedCoords, 2.5, GetHashKey("prop_fbibombplant"), false)
				local objectId3 = GetClosestObjectOfType(pedCoords, 2.5, GetHashKey("p_int_jewel_plant_02"), false)
				local objectCoords = GetEntityCoords(objectId)
				local objectCoords2 = GetEntityCoords(objectId2)
				local objectCoords3 = GetEntityCoords(objectId3)
				local sprawdzOtoczenie = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, objectCoords.x, objectCoords.y, objectCoords.z)
				local sprawdzOtoczenie2 = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, objectCoords2.x, objectCoords2.y, objectCoords2.z)
				local sprawdzOtoczenie3 = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, objectCoords3.x, objectCoords3.y, objectCoords3.z)
				if sprawdzOtoczenie <= 3.0 or sprawdzOtoczenie2 <= 3.0 or sprawdzOtoczenie3 <= 3.0 then
					ESX.ShowNotification('~y~Ktoś tu już posadził.')
				else
					WybierzRosline()
				end
			else
				ESX.ShowNotification('~y~Nie masz wody / Nie masz nasion.')
			end
        end
		
		if IsControlJustPressed(0, Keys['E']) and posadzone == 1 then
		TaskStartScenarioInPlace(GetPlayerPed(-1), "WORLD_HUMAN_GARDENER_PLANT", 0, false)
		Citizen.Wait(500)
		DeleteEntity(obiekt)
		posadzone = 0
			if wyborRosliny == 1 then
			TriggerServerEvent("tost:zbierzroslinke",1)
			elseif wyborRosliny == 2 then
			TriggerServerEvent("tost:zbierzroslinke",2)
			elseif wyborRosliny == 3 then
			TriggerServerEvent("tost:zbierzroslinke",3)
			end
		wyborRosliny = 0
		ClearPedTasks(GetPlayerPed(-1))
		Citizen.Wait(1500)
        end
		
	end
		
      end
   end
end)

function PosadzDrzewko(rodzaj)
 for k in pairs(MiejsceSadzenia) do
 local pedCoords = GetEntityCoords(PlayerPedId())
 local dist = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, MiejsceSadzenia[k].x, MiejsceSadzenia[k].y, MiejsceSadzenia[k].z)
 if dist <= 2.0 then
	TaskStartScenarioInPlace(GetPlayerPed(-1), "WORLD_HUMAN_GARDENER_PLANT", 0, false)
	obiekt = CreateObject(GetHashKey(rodzaj), MiejsceSadzenia[k].x, MiejsceSadzenia[k].y, MiejsceSadzenia[k].z-2.95, true, true, true)
	FreezeEntityPosition(obiekt, true)
	SetEntityAsMissionEntity(obiekt)
	posadzone = 3
	Citizen.Wait(500)
	ClearPedTasks(GetPlayerPed(-1))
	Citizen.Wait(1500)
	local objCoords = GetEntityCoords(obiekt)
	procent = 0
	for i=1, 3350, 1 do
	Citizen.Wait(5)
	wzrost = wzrost +0.0004
	procent = procent +0.03
	SetEntityCoords(obiekt, objCoords.x, objCoords.y, objCoords.z +wzrost)
	DrawText3D(objCoords.x, objCoords.y, objCoords.z+2.5,'~g~Rośnie:~y~ '..math.floor(procent)..'%')
	end
	posadzone = 1
	wzrost = 0
end
end
end
------------------------------------
function DrawText3D(x, y, z, text)
    local onScreen,_x,_y=World3dToScreen2d(x, y, z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    
    SetTextScale(0.37, 0.37)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 11, 11, 11, 90)
end


------------------------------------
function WybierzRosline()
local elements = {}

	if (nasionoKonopi > 0)  then
	table.insert(elements, {label = '<font color=green><b>'..roslina1Nazwa..'<font>' , value = '11'})
	end
	
	if (nasionoMakowca > 0) then
	table.insert(elements, {label = '<font color=yellow><b>'..roslina2Nazwa..'<font>' , value = '22'})
	end
	
	if (nasionoKoki > 0) then
	table.insert(elements, {label = '<font color=red><b>'..roslina3Nazwa..'<font>' , value = '33'})
	end
	
ESX.UI.Menu.Open(
	'default', GetCurrentResourceName(), 'roslina_menu',
	{
		title    = 'Co chcesz posadzić?',
		align    = 'center',
		elements = elements
	},
	function(data2, menu2)
		local inventory = ESX.GetPlayerData().inventory
		local count = 0
		local count2 = 0
		local count3 = 0
		for i=1, #inventory, 1 do
			if inventory[i].name == 'nasionko' then
			count = inventory[i].count
			end
			if inventory[i].name == 'nasiono2' then
			count2 = inventory[i].count
			end
			if inventory[i].name == 'nasiono3' then
			count3 = inventory[i].count
			end
		end
				
		if data2.current.value == '11' then
			if (count > 0) then
			menu2.close()
			TriggerServerEvent("tost:zbierzroslinke",10)
			wyborRosliny = 1
			PosadzDrzewko('prop_plant_int_03c')
			else
			ESX.ShowNotification('~y~Nie masz nasion!')
			end
		elseif data2.current.value == '22' then
			if (count2 > 0) then
			menu2.close()
			TriggerServerEvent("tost:zbierzroslinke",11)
			wyborRosliny = 2
			PosadzDrzewko('prop_fbibombplant')
			else
			ESX.ShowNotification('~y~Nie masz nasion!')
			end
        elseif data2.current.value == '33' then
			if (count3 > 0) then
			menu2.close()
			TriggerServerEvent("tost:zbierzroslinke",12)
			wyborRosliny = 3
			PosadzDrzewko('p_int_jewel_plant_02')
			else
			ESX.ShowNotification('~y~Nie masz nasion!')
			end
			end
		
	end,
	function(data2, menu2)
		menu2.close()
	
end)
end
---
Citizen.CreateThread(function()
    while true do
	Citizen.Wait(2500)

	local pedCoords = GetEntityCoords(PlayerPedId())
    local distKonopia = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, SprzedazKonopi.x, SprzedazKonopi.y, SprzedazKonopi.z)
	local distMakowiec = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, SprzedazMakowca.x, SprzedazMakowca.y, SprzedazMakowca.z)
	local distKoka = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, SprzedazKoki.x, SprzedazKoki.y, SprzedazKoki.z)
	
if distKonopia <= 15.0 or distKonopia <= 15.0 or distKonopia <= 15.0 then
	local inventory = ESX.GetPlayerData().inventory
	for i=1, #inventory, 1 do
		if inventory[i].name == 'liscie1' then
		liscieKonopi = inventory[i].count
		end
		if inventory[i].name == 'liscie2' then
		liscieMakowca = inventory[i].count
		end
		if inventory[i].name == 'liscie3' then
		liscieKoki = inventory[i].count
		end
	end
else
Citizen.Wait(4000)
end
	
	
end	
end)
---


Citizen.CreateThread(function()
    while true do
	Citizen.Wait(5)

	local pedCoords = GetEntityCoords(PlayerPedId())
    local distKonopia = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, SprzedazKonopi.x, SprzedazKonopi.y, SprzedazKonopi.z)
	local distMakowiec = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, SprzedazMakowca.x, SprzedazMakowca.y, SprzedazMakowca.z)
	local distKoka = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, SprzedazKoki.x, SprzedazKoki.y, SprzedazKoki.z)
	
	if distKonopia <= 25.0 or distKonopia <= 25.0 or distKonopia <= 25.0 then
		if (liscieKonopi > 0 ) then
		DrawMarker(23, SprzedazKonopi.x, SprzedazKonopi.y, SprzedazKonopi.z-0.95, 0, 0, 0, 0, 0, 0, 1.6, 1.6, 1.6, 255, 255, 0, 200, 0, 0, 0, 0)
		end
		if (liscieMakowca > 0 ) then
		DrawMarker(23, SprzedazMakowca.x, SprzedazMakowca.y, SprzedazMakowca.z-0.95, 0, 0, 0, 0, 0, 0, 1.6, 1.6, 1.6, 255, 255, 0, 200, 0, 0, 0, 0)
		end
		if (liscieKoki > 0 ) then
		DrawMarker(23, SprzedazKoki.x, SprzedazKoki.y, SprzedazKoki.z-0.95, 0, 0, 0, 0, 0, 0, 1.6, 1.6, 1.6, 255, 255, 0, 200, 0, 0, 0, 0)
		end
	else
	Citizen.Wait(1500)
	end
	
	if distKonopia <= 2.0 and liscieKonopi > 0 then
		DrawText3D(SprzedazKonopi.x, SprzedazKonopi.y, SprzedazKonopi.z,'~g~[E] ~y~Aby przerobić konopię')
		if IsControlJustPressed(0, Keys['E']) then
		PakujNarkotyk('konopia')
		end
	end
	
	if distMakowiec <= 2.0 and liscieMakowca > 0 then
		DrawText3D(SprzedazMakowca.x, SprzedazMakowca.y, SprzedazMakowca.z,'~g~[E] ~y~Aby przerobić makowiec')
		if IsControlJustPressed(0, Keys['E']) then
		PakujNarkotyk('makowiec')
		end
	end
	
	if distKoka <= 2.0 and liscieKoki > 0 then
		DrawText3D(SprzedazKoki.x, SprzedazKoki.y, SprzedazKoki.z,'~g~[E] ~y~Aby przerobić liście koki')
		if IsControlJustPressed(0, Keys['E']) then
		PakujNarkotyk('koka')
		end
	end
	
	
end
end)

function PakujNarkotyk(rodzaj)
if rodzaj == 'konopia' then
ESX.ShowNotification('~y~Przerabiasz liście konopi.')
TaskStartScenarioInPlace(GetPlayerPed(-1), "CODE_HUMAN_MEDIC_KNEEL", 0, false)
Citizen.Wait(5000)
ClearPedTasks(GetPlayerPed(-1))
TriggerServerEvent("tostkrzaki:przerobnarkoty",'konopia')

end
if rodzaj == 'makowiec' then
ESX.ShowNotification('~y~Przerabiasz liście opium.')
TaskStartScenarioInPlace(GetPlayerPed(-1), "CODE_HUMAN_MEDIC_KNEEL", 0, false)
Citizen.Wait(5000)
ClearPedTasks(GetPlayerPed(-1))
TriggerServerEvent("tostkrzaki:przerobnarkoty",'makowiec')
end
if rodzaj == 'koka' then
ESX.ShowNotification('~y~Przerabiasz liście koki.')
TaskStartScenarioInPlace(GetPlayerPed(-1), "CODE_HUMAN_MEDIC_KNEEL", 0, false)
Citizen.Wait(5000)
ClearPedTasks(GetPlayerPed(-1))
TriggerServerEvent("tostkrzaki:przerobnarkoty",'koka')
end
end