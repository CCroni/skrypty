--------------------------------------------
------ Napisane przez wojtek.cfg#0349 ------
----------------- ©  2019 ------------------
--------------------------------------------

local Keys = {
  ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
  ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
  ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
  ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
  ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
  ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
  ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
  ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
}

ESX                      = nil

local Akt         			 = nil
local CurrentActionMsg   = ''
local CurrentActionData  = {}
local JestWMarkerze 		 = false
local OstStrefa          = nil
local Czaspozostaly			 = 0
local PlayerData         = {}
local pracuje            = false

-- Std. def. wyborów - lepiej nie ruszaj -- 
local wybor1             = 0
local wybor2             = 0
local wybor3             = 0
local wybor4             = 0
local wybor5             = 0
local st                 = 0
local pomylka            = 0

local dict = 'gestures@m@standing@casual'


Citizen.CreateThread(function ()
  while ESX == nil do
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    Citizen.Wait(0)
 	PlayerData = ESX.GetPlayerData()
  end
  	odswiezblipy()
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
  	odswiezblipy()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  PlayerData.job = job
  	odswiezblipy()
end)

function odswiezblipy() 

  if Config.blipyoff == false and Config.potrzebnapraca == false then

  blip1 = AddBlipForCoord(-1719.86, -1104.20, 12.1)
  SetBlipSprite (blip1, Config.ikonka)
  SetBlipDisplay(blip1, 4)
  SetBlipScale  (blip1, Config.wielkoscikonki)
  SetBlipColour (blip1, Config.kolorikonki )
  SetBlipAsShortRange(blip1, true)
  BeginTextCommandSetBlipName("STRING")
  AddTextComponentString('Sprzedawanie hot-dogów')
  EndTextCommandSetBlipName(blip1)

 blip2 = AddBlipForCoord(-1771.98, -1161.04, 12.1)
    SetBlipSprite (blip2, Config.ikonka)
    SetBlipDisplay(blip2, 4)
    SetBlipScale  (blip2, Config.wielkoscikonki)
    SetBlipColour (blip2, Config.kolorikonki )
    SetBlipAsShortRange(blip2, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString('Sprzedawanie hot-dogów')
    EndTextCommandSetBlipName(blip2)

    if Config.dodatkowebudki == true then
      blip3 = AddBlipForCoord(232.51, -901.48, 29.7)
      SetBlipSprite (blip3, Config.ikonka)
      SetBlipDisplay(blip3, 4)
      SetBlipScale  (blip3, Config.wielkoscikonki)
      SetBlipColour (blip3, Config.kolorikonki)
      SetBlipAsShortRange(blip3, true)
      BeginTextCommandSetBlipName("STRING")
      AddTextComponentString('Sprzedawanie hot-dogów')
      EndTextCommandSetBlipName(blip3)

      blip4 = AddBlipForCoord(230.29, -904.86, 29.7)
      SetBlipSprite (blip4, Config.ikonka)
      SetBlipDisplay(blip4, 4)
      SetBlipScale  (blip4, Config.wielkoscikonki)
      SetBlipColour (blip4, Config.kolorikonki )
      SetBlipAsShortRange(blip4, true)
      BeginTextCommandSetBlipName("STRING")
      AddTextComponentString('Sprzedawanie hot-dogów')
      EndTextCommandSetBlipName(blip4)
    elseif Config.dodatkowebudki == false then
      RemoveBlip(blip3)
      RemoveBlip(blip4)
    end
  elseif Config.potrzebnapraca == true and PlayerData.job ~= nil and PlayerData.job.name == 'hotdog' then
    blip1 = AddBlipForCoord(-1719.86, -1104.20, 12.1)
    SetBlipSprite (blip1, Config.ikonka)
    SetBlipDisplay(blip1, 4)
    SetBlipScale  (blip1, Config.wielkoscikonki)
    SetBlipColour (blip1, Config.kolorikonki )
    SetBlipAsShortRange(blip1, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString('Sprzedawanie hot-dogów')
    EndTextCommandSetBlipName(blip1)
  
   blip2 = AddBlipForCoord(-1771.98, -1161.04, 12.1)
      SetBlipSprite (blip2, Config.ikonka)
      SetBlipDisplay(blip2, 4)
      SetBlipScale  (blip2, Config.wielkoscikonki)
      SetBlipColour (blip2, Config.kolorikonki )
      SetBlipAsShortRange(blip2, true)
      BeginTextCommandSetBlipName("STRING")
      AddTextComponentString('Sprzedawanie hot-dogów')
      EndTextCommandSetBlipName(blip2)
  
      if Config.dodatkowebudki == true then
        blip3 = AddBlipForCoord(232.51, -901.48, 29.7)
        SetBlipSprite (blip3, Config.ikonka)
        SetBlipDisplay(blip3, 4)
        SetBlipScale  (blip3, Config.wielkoscikonki)
        SetBlipColour (blip3, Config.kolorikonki)
        SetBlipAsShortRange(blip3, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString('Sprzedawanie hot-dogów')
        EndTextCommandSetBlipName(blip3)
  
        blip4 = AddBlipForCoord(230.29, -904.86, 29.7)
        SetBlipSprite (blip4, Config.ikonka)
        SetBlipDisplay(blip4, 4)
        SetBlipScale  (blip4, Config.wielkoscikonki)
        SetBlipColour (blip4, Config.kolorikonki )
        SetBlipAsShortRange(blip4, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString('Sprzedawanie hot-dogów')
        EndTextCommandSetBlipName(blip4)
      elseif Config.dodatkowebudki == false then
        RemoveBlip(blip3)
        RemoveBlip(blip4)
      end
    end
end



function LoadDict(dict)
  RequestAnimDict(dict)
while not HasAnimDictLoaded(dict) do
    Citizen.Wait(10)
  end
end


AddEventHandler('wojtek_hotdogi:wmarkerze', function (zone)
if Config.potrzebnapraca == false then
  if zone == 'budka1' and pracuje == false then
    Akt     = 'bud'
    CurrentActionMsg  = ('Kliknij ~INPUT_CONTEXT~ aby ~g~sprzedawać ~w~hot-dogi')
    CurrentActionData = {}
  elseif zone == 'budka2' and pracuje == false then
    Akt	  = 'bud'
	CurrentActionMsg  = ('Kliknij ~INPUT_CONTEXT~ aby ~g~sprzedawać ~w~hot-dogi')
	CurrentActionData = {}
  elseif zone == 'budka3' and Config.dodatkowebudki == true and pracuje == false then
    Akt	  = 'bud2'
	CurrentActionMsg  = ('Kliknij ~INPUT_CONTEXT~ aby ~g~sprzedawać ~w~hot-dogi')
	CurrentActionData = {}
  elseif zone == 'budka4' and Config.dodatkowebudki == true and pracuje == false then
    Akt	  = 'bud2'
	CurrentActionMsg  = ('Kliknij ~INPUT_CONTEXT~ aby ~g~sprzedawać ~w~hot-dogi')
	CurrentActionData = {}
  end
elseif Config.potrzebnapraca == true and PlayerData.job ~= nil and PlayerData.job.name == 'hotdog' then
  if zone == 'budka1' and pracuje == false then
    Akt     = 'bud'
    CurrentActionMsg  = ('Kliknij ~INPUT_CONTEXT~ aby ~g~sprzedawać ~w~hot-dogi')
    CurrentActionData = {}
  elseif zone == 'budka2' and pracuje == false then
    Akt	  = 'bud'
	CurrentActionMsg  = ('Kliknij ~INPUT_CONTEXT~ aby ~g~sprzedawać ~w~hot-dogi')
	CurrentActionData = {}
  elseif zone == 'budka3' and Config.dodatkowebudki == true and pracuje == false then
    Akt	  = 'bud2'
	CurrentActionMsg  = ('Kliknij ~INPUT_CONTEXT~ aby ~g~sprzedawać ~w~hot-dogi')
	CurrentActionData = {}
  elseif zone == 'budka4' and Config.dodatkowebudki == true and pracuje == false then
    Akt	  = 'bud2'
	CurrentActionMsg  = ('Kliknij ~INPUT_CONTEXT~ aby ~g~sprzedawać ~w~hot-dogi')
	CurrentActionData = {}
  end
end
end)



AddEventHandler('wojtek_hotdogi:pozamarkerem', function (zone)
  Akt = nil
end)



Citizen.CreateThread(function()
  while true do

    Citizen.Wait(0)

  if Akt ~= nil then

    SetTextComponentFormat('STRING')
    AddTextComponentString(CurrentActionMsg)
    DisplayHelpTextFromStringLabel(0, 0, 1, -1)

    if IsControlPressed(0,  Keys['E']) then
		
		if Akt == 'bud' and pracuje == false then
			TriggerEvent('wojtek_hotdogi:rozpocznij')
		end

		if Akt == 'bud2' and Config.dodatkowebudki == true and pracuje == false then
			TriggerEvent('wojtek_hotdogi:rozpocznij')
		end
		
		
      end
    end
  end
end)

RegisterNetEvent('wojtek_hotdogi:rozpocznij')
AddEventHandler('wojtek_hotdogi:rozpocznij', function(xPlayer)

  Powiadomieniekilent()

  if pracuje == false then
    pracuje = true
  end


  Menuhotdogi1()


end)

function Powiadomieniekilent()
  local _source = source
  local losowosc = math.random(1,5)

  if losowosc == 1 and pracuje == false then
    ikonka = "CHAR_AMANDA"
  elseif losowosc == 2 then
    ikonka = "CHAR_BARRY"
  elseif losowosc == 3 then
    ikonka = "CHAR_ANTONIA"
  elseif losowosc == 4 then
    ikonka = "CHAR_BEVERLY"
  elseif losowosc == 5 then
    ikonka = "CHAR_DENISE"
  end
--
  local wybor1 = math.random(1,3)

    if wybor1 == 1 then
      los1 = 1
    elseif wybor1 == 2 then
      los1 = 2
    elseif wybor1 == 3 then
      los1 = 3
    end

    if los1 == 1 then
      wyb1 = "Małego"
    elseif los1 == 2 then
      wyb1 = "Średniego"
    else
      wyb1 = "Dużego"
    end
--
    local wybor2 = math.random(1,3)

    if wybor2 == 1 then
      los2 = 1
    elseif wybor2 == 2 then
      los2 = 2
    elseif wybor2 == 3 then
      los2 = 3
    end

    if los2 == 1 then
      wyb2 = "parówką"
    elseif los2 == 2 then
      wyb2 = "kabanosem"
    elseif los2 == 3 then
      wyb2 = "kiełbasą"
    end  
--
    local wybor3 = math.random(1,2)

    if wybor3 == 1 then
      los3 = 1
    elseif wybor3 == 2 then
      los3 = 2
    end

    if los3 == 1 then
      wyb3 = "zwykłej"
    elseif los3 == 2 then
      wyb3 = "pełnoziarnistej"
    end
--

  local wybor4 = math.random(1,2)

  if wybor4 == 1 then
    los4 = 1
  else
    los4 = 2
  end

  if los4 == 1 then
    wyb4 = "~g~z dodatkami"
  else
    wyb4 = "~r~bez dodatków"
  end
--

  local wybor5 = math.random(1,4)

  if wybor5 == 1 then
    los5 = 1
  elseif wybor5 == 2 then
    los5 = 2
  elseif wybor5  == 3 then
    los5 = 3
  elseif wybor5 == 4 then
    los5 = 4
  end

  if los5 == 1 then
    wyb5 = "z ketchupem"
  elseif los5 == 2 then
    wyb5 = "z musztardą"
  elseif los5 == 3 then
    wyb5 = "z łagodnym sosem"
  elseif los5 == 4 then
    wyb5 = "z ostrym sosem"
  end
--


  local czas = 0.8
  wiadomosc = "Poproszę~g~ "..wyb1.." ~w~hot-doga z~g~ "..wyb2.." ~w~w ~g~"..wyb3.." ~w~bułce, "
  SetNotificationTextEntry("STRING")
  AddTextComponentString(wiadomosc)
  Citizen.InvokeNative(0x1E6611149DB3DB6B, ikonka, ikonka, true, 1, "Klient", "~y~zamówienie", czas)
  DrawNotification_4(false, true)

  TriggerEvent('esx:showNotification', '~w~'..wyb4..', i ~g~'..wyb5..'~w~.')
  end

function Dzieki()

  local czas = 0.4
  wiadomosc = "Ten Hot-Dog jest idealny, Dziękuję!"
  SetNotificationTextEntry("STRING")
  AddTextComponentString(wiadomosc)
  Citizen.InvokeNative(0x1E6611149DB3DB6B, ikonka, ikonka, true, 1, "Klient", "~g~zadowolony", czas)
  DrawNotification_4(false, true)

end

function zle()

  local czas = 0.4
  wiadomosc = "Ugh, to nie jest moje zamówienie!"
  SetNotificationTextEntry("STRING")
  AddTextComponentString(wiadomosc)
  Citizen.InvokeNative(0x1E6611149DB3DB6B, ikonka, ikonka, true, 1, "Klient", "~r~zdenerwowany", czas)
  DrawNotification_4(false, true)

end


function Menuhotdogi1()
  ESX.UI.Menu.CloseAll()

  ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'przygotowywanie',
    {
      title    = 'Hot-dog',
	  align    = 'center',
      elements = {
        {label = 'Duży', value = 'duzy'},
				{label = 'Średni', value = 'sredni'},
				{label = 'Mały', value = 'maly'}
      }
    },
    function(data, menu)
			if data.current.value == 'duzy' then
      st1 = 3
      TriggerEvent('wojtek_hotdogi:sprawdz1')
			elseif data.current.value == 'sredni' then
      st1 = 2
      TriggerEvent('wojtek_hotdogi:sprawdz1')
			elseif data.current.value == 'maly' then
      st1 = 1
      TriggerEvent('wojtek_hotdogi:sprawdz1')
      end

      if st1 == los1 then
        FreezeEntityPosition(GetPlayerPed(-1), true)
        menu.close()
        pozostalo1 = Config.czasanimacji
        TaskStartScenarioInPlace(GetPlayerPed(-1), "PROP_HUMAN_BUM_BIN", 0, true)
        TriggerEvent("pNotify:SendNotification",{
          text = ('Przygotowujesz hot-doga'),
          type = "info",
          timeout = (Config.czasanimacji * 1000),
          layout = "bottomCenter",
          queue = "hotdog",
          animation = {
          open = "gta_effects_fade_in",
          close = "gta_effects_fade_out"
        }})
        repeat
          pozostalo1 = pozostalo1 - 1
          Citizen.Wait(1000)
        until(pozostalo1 == 0)
        Menuhotdogi2()
        ClearPedTasksImmediately(GetPlayerPed(-1))
        
        FreezeEntityPosition(GetPlayerPed(-1), false)
      else
        FreezeEntityPosition(GetPlayerPed(-1), true)
        menu.close()
        pozostalo1 = Config.czasanimacji
        TaskStartScenarioInPlace(GetPlayerPed(-1), "PROP_HUMAN_BUM_BIN", 0, true)
        TriggerEvent("pNotify:SendNotification",{
          text = ('Przygotowujesz hot-doga'),
          type = "info",
          timeout = (Config.czasanimacji * 1000),
          layout = "bottomCenter",
          queue = "hotdog",
          animation = {
          open = "gta_effects_fade_in",
          close = "gta_effects_fade_out"
        }})
        repeat
          pozostalo1 = pozostalo1 - 1
          Citizen.Wait(1000)
        until(pozostalo1 == 0)
        Menuhotdogi2()
        ClearPedTasksImmediately(GetPlayerPed(-1))
        
        FreezeEntityPosition(GetPlayerPed(-1), false)
        pomylka = 1
      end

		end,
		function(data, menu)
      menu.close()
      FreezeEntityPosition(GetPlayerPed(-1), false)
    end
  )
end

function Menuhotdogi2()
  ESX.UI.Menu.CloseAll()

  ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'przygotowywanie',
    {
      title    = 'Z czym?',
	  align    = 'center',
      elements = {
        {label = 'Parówka', value = 'paro'},
				{label = 'Kabanos', value = 'kaba'},
        {label = 'Kiełbasa', value = 'kiel'}
      }
    },
    function(data, menu)
			if data.current.value == 'paro' then
		  st2 = 1
			elseif data.current.value == 'kaba' then
			st2 = 2
			elseif data.current.value == 'kiel' then
			st2 = 3
      end

      if st2 == los2 then
        FreezeEntityPosition(GetPlayerPed(-1), true)
        menu.close()
        pozostalo1 = Config.czasanimacji
        TaskStartScenarioInPlace(GetPlayerPed(-1), "PROP_HUMAN_BBQ", 0, true)
        TriggerEvent("pNotify:SendNotification",{
          text = ('Przygotowujesz hot-doga'),
          type = "info",
          timeout = (Config.czasanimacji * 1000),
          layout = "bottomCenter",
          queue = "hotdog",
          animation = {
          open = "gta_effects_fade_in",
          close = "gta_effects_fade_out"
        }})
        repeat
          pozostalo1 = pozostalo1 - 1
          Citizen.Wait(1000)
        until(pozostalo1 == 0)
        Menuhotdogi3()
        ClearPedTasksImmediately(GetPlayerPed(-1))
        
        FreezeEntityPosition(GetPlayerPed(-1), false)
      else
        FreezeEntityPosition(GetPlayerPed(-1), true)
        menu.close()
        pozostalo1 = Config.czasanimacji
        TaskStartScenarioInPlace(GetPlayerPed(-1), "PROP_HUMAN_BUM_BIN", 0, true)
        TriggerEvent("pNotify:SendNotification",{
          text = ('Przygotowujesz hot-doga'),
          type = "info",
          timeout = (Config.czasanimacji * 1000),
          layout = "bottomCenter",
          queue = "hotdog",
          animation = {
          open = "gta_effects_fade_in",
          close = "gta_effects_fade_out"
        }})
        repeat
          pozostalo1 = pozostalo1 - 1
          Citizen.Wait(1000)
        until(pozostalo1 == 0)
        Menuhotdogi3()
        ClearPedTasksImmediately(GetPlayerPed(-1))
        
        FreezeEntityPosition(GetPlayerPed(-1), false)
        pomylka = 1
      end

		end,
		function(data, menu)
      menu.close()
      FreezeEntityPosition(GetPlayerPed(-1), false)
    end
  )
end

function Menuhotdogi3()
  ESX.UI.Menu.CloseAll()

  ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'przygotowywanie',
    {
      title    = 'Bułka',
	  align    = 'center',
      elements = {
        {label = 'Zwykła', value = 'zwykla'},
				{label = 'Pełnoziarnista', value = 'pelno'}
      }
    },
    function(data, menu)
			if data.current.value == 'zwykla' then
		  st3 = 1
			elseif data.current.value == 'pelno' then
			st3 = 2
      end

      if st3 == los3 then
        FreezeEntityPosition(GetPlayerPed(-1), true)
        menu.close()
        pozostalo1 = Config.czasanimacji
        TaskStartScenarioInPlace(GetPlayerPed(-1), "PROP_HUMAN_BUM_BIN", 0, true)
        TriggerEvent("pNotify:SendNotification",{
          text = ('Przygotowujesz hot-doga'),
          type = "info",
          timeout = (Config.czasanimacji * 1000),
          layout = "bottomCenter",
          queue = "hotdog",
          animation = {
          open = "gta_effects_fade_in",
          close = "gta_effects_fade_out"
        }})
        repeat
          pozostalo1 = pozostalo1 - 1
          Citizen.Wait(1000)
        until(pozostalo1 == 0)
        Menuhotdogi4()
        ClearPedTasksImmediately(GetPlayerPed(-1))
        
        FreezeEntityPosition(GetPlayerPed(-1), false)
      else
        FreezeEntityPosition(GetPlayerPed(-1), true)
        menu.close()
        pozostalo1 = Config.czasanimacji
        TaskStartScenarioInPlace(GetPlayerPed(-1), "PROP_HUMAN_BUM_BIN", 0, true)
        TriggerEvent("pNotify:SendNotification",{
          text = ('Przygotowujesz hot-doga'),
          type = "info",
          timeout = (Config.czasanimacji * 1000),
          layout = "bottomCenter",
          queue = "hotdog",
          animation = {
          open = "gta_effects_fade_in",
          close = "gta_effects_fade_out"
        }})
        repeat
          pozostalo1 = pozostalo1 - 1
          Citizen.Wait(1000)
        until(pozostalo1 == 0)
        Menuhotdogi4()
        ClearPedTasksImmediately(GetPlayerPed(-1))
        
        FreezeEntityPosition(GetPlayerPed(-1), false)
        pomylka = 1
      end

		end,
		function(data, menu)
      menu.close()
      FreezeEntityPosition(GetPlayerPed(-1), false)
    end
  )
end

function Menuhotdogi4()
  ESX.UI.Menu.CloseAll()

  ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'przygotowywanie',
    {
      title    = 'Hot-dog',
	  align    = 'center',
      elements = {
        {label = 'Z dodatkami', value = 'z'},
				{label = 'bez dodatków', value = 'bez'}
      }
    },
    function(data, menu)
			if data.current.value == 'z' then
		  st4 = 1
			elseif data.current.value == 'bez' then
			st4 = 2
      end

      if st4 == los4 then
        FreezeEntityPosition(GetPlayerPed(-1), true)
        menu.close()
        pozostalo1 = Config.czasanimacji
        TaskStartScenarioInPlace(GetPlayerPed(-1), "PROP_HUMAN_BUM_BIN", 0, true)
        TriggerEvent("pNotify:SendNotification",{
          text = ('Przygotowujesz hot-doga'),
          type = "info",
          timeout = (Config.czasanimacji * 1000),
          layout = "bottomCenter",
          queue = "hotdog",
          animation = {
          open = "gta_effects_fade_in",
          close = "gta_effects_fade_out"
        }})
        repeat
          pozostalo1 = pozostalo1 - 1
          Citizen.Wait(1000)
        until(pozostalo1 == 0)
        Menuhotdogi5()
        ClearPedTasksImmediately(GetPlayerPed(-1))
        
        FreezeEntityPosition(GetPlayerPed(-1), false)
      else
        FreezeEntityPosition(GetPlayerPed(-1), true)
        menu.close()
        pozostalo1 = Config.czasanimacji
        TaskStartScenarioInPlace(GetPlayerPed(-1), "PROP_HUMAN_BUM_BIN", 0, true)
        TriggerEvent("pNotify:SendNotification",{
          text = ('Przygotowujesz hot-doga'),
          type = "info",
          timeout = (Config.czasanimacji * 1000),
          layout = "bottomCenter",
          queue = "hotdog",
          animation = {
          open = "gta_effects_fade_in",
          close = "gta_effects_fade_out"
        }})
        repeat
          pozostalo1 = pozostalo1 - 1
          Citizen.Wait(1000)
        until(pozostalo1 == 0)
        Menuhotdogi5()
        ClearPedTasksImmediately(GetPlayerPed(-1))
        
        FreezeEntityPosition(GetPlayerPed(-1), false)
        pomylka = 1
      end

		end,
		function(data, menu)
      menu.close()
      FreezeEntityPosition(GetPlayerPed(-1), false)
    end
  )
end

function Menuhotdogi5()
  ESX.UI.Menu.CloseAll()

  ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'przygotowywanie',
    {
      title    = 'Sos',
	  align    = 'center',
      elements = {
        {label = 'Ketchup', value = 'ket'},
				{label = 'Musztarda', value = 'musz'},
        {label = 'Łagodny', value = 'lag'},
        {label = 'Ostry', value = 'ost'}
      }
    },
    function(data, menu)
			if data.current.value == 'ket' then
		  st5 = 1
			elseif data.current.value == 'musz' then
			st5 = 2
			elseif data.current.value == 'lag' then
      st5 = 3
      elseif data.current.value == 'ost' then
			st5 = 4
      end

      if st5 == los5 and pomylka == 0 then
        LoadDict(dict)
        FreezeEntityPosition(GetPlayerPed(-1), true)
        menu.close()
        ClearPedTasksImmediately(GetPlayerPed(-1))
        TriggerServerEvent('wojtek_hotdogi:hajs')
        Dzieki()
        TaskPlayAnim(GetPlayerPed(-1), dict, "gesture_point", 3.0, -8, -1, 63, 0, 0, 0, 0 )
        Wait(1000)
        ClearPedTasksImmediately(GetPlayerPed(-1))
        if pracuje == true then
          pracuje = false
        end

        FreezeEntityPosition(GetPlayerPed(-1), false)
      else
        LoadDict(dict)
        TaskPlayAnim(GetPlayerPed(-1), dict, "gesture_damn", 3.0, -8, -1, 63, 0, 0, 0, 0 )
        zle()
        TriggerEvent('esx:showNotification', '~o~Pomyliłeś się, klient odchodzi.')
        menu.close()
        Wait(1000)
        ClearPedTasksImmediately(GetPlayerPed(-1))
        FreezeEntityPosition(GetPlayerPed(-1), false)
        Wait(1500)
        if pracuje == true then
          pracuje = false
        end

        if pomylka == 1 then
          pomylka = 0
        end
      end

		end,
		function(data, menu)
      menu.close()
      FreezeEntityPosition(GetPlayerPed(-1), false)
    end
  )
end


Citizen.CreateThread(function ()
  while true do
    Wait(0)

    local coords = GetEntityCoords(GetPlayerPed(-1))

if Config.potrzebnapraca == false then
    for k,v in pairs(Config.strefastandardowebudki) do
      if(v.Type ~= -1 and GetDistanceBetweenCoords(coords, v.Pos.x, v.Pos.y, v.Pos.z, true) < 100.0) then
        DrawMarker(v.Type, v.Pos.x, v.Pos.y, v.Pos.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, v.Size.x, v.Size.y, v.Size.z, v.Color.r, v.Color.g, v.Color.b, 300, false, true, 2, false, false, false, false)
      end
    end
	for k,v in pairs(Config.strefadodatkowebudki) do
      if(v.Type ~= -1 and GetDistanceBetweenCoords(coords, v.Pos.x, v.Pos.y, v.Pos.z, true) < 100.0) and Config.dodatkowebudki == true then
        DrawMarker(v.Type, v.Pos.x, v.Pos.y, v.Pos.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, v.Size.x, v.Size.y, v.Size.z, v.Color.r, v.Color.g, v.Color.b, 300, false, true, 2, false, false, false, false)
      end
  end
elseif Config.potrzebnapraca == true and PlayerData.job ~= nil and PlayerData.job.name == 'hotdog' then
      for k,v in pairs(Config.strefastandardowebudki) do
        if(v.Type ~= -1 and GetDistanceBetweenCoords(coords, v.Pos.x, v.Pos.y, v.Pos.z, true) < 100.0) then
          DrawMarker(v.Type, v.Pos.x, v.Pos.y, v.Pos.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, v.Size.x, v.Size.y, v.Size.z, v.Color.r, v.Color.g, v.Color.b, 300, false, true, 2, false, false, false, false)
        end
      end
    for k,v in pairs(Config.strefadodatkowebudki) do
        if(v.Type ~= -1 and GetDistanceBetweenCoords(coords, v.Pos.x, v.Pos.y, v.Pos.z, true) < 100.0) and Config.dodatkowebudki == true then
          DrawMarker(v.Type, v.Pos.x, v.Pos.y, v.Pos.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, v.Size.x, v.Size.y, v.Size.z, v.Color.r, v.Color.g, v.Color.b, 300, false, true, 2, false, false, false, false)
        end
    end
end
  end
end)



Citizen.CreateThread(function ()
  while true do
    Wait(0)

    local coords      = GetEntityCoords(GetPlayerPed(-1))
    local isInMarker  = false
    local currentZone = nil

			for k,v in pairs(Config.strefastandardowebudki) do
				if(GetDistanceBetweenCoords(coords, v.Pos.x, v.Pos.y, v.Pos.z, true) < v.Size.x) then
				isInMarker  = true
				currentZone = k
				end
			end
	
			for k,v in pairs(Config.strefadodatkowebudki) do
				if(GetDistanceBetweenCoords(coords, v.Pos.x, v.Pos.y, v.Pos.z, true) < v.Size.x) then
				isInMarker  = true
				currentZone = k
				end
			end

    if (isInMarker and not JestWMarkerze) or (isInMarker and OstStrefa ~= currentZone) then
      JestWMarkerze = true
      OstStrefa                = currentZone
      TriggerEvent('wojtek_hotdogi:wmarkerze', currentZone)
    end

    if not isInMarker and JestWMarkerze then
	  TriggerEvent('wojtek_hotdogi:pozamarkerem', OstStrefa)
      JestWMarkerze = false
      TriggerEvent('esx:showNotification', '~r~Wyszedłeś z markera!')
      if pracuje == true then
        pracuje = false
      end
    end
  end
end)





--------------------------------------------
------ Napisane przez wojtek.cfg#0349 ------
----------------- ©  2019 ------------------
--------------------------------------------
