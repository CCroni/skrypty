

INSERT INTO `job_grades` (`id`, `job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES
(NULL, 'hotdog', 0, 'pracownik', 'Sprzedawca', 50, '{}', '{}');

INSERT INTO `jobs` (`name`, `label`, `whitelisted`) VALUES
('hotdog', 'Hot-Dogi', 0);





