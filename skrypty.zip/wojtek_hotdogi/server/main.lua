--------------------------------------------
------ Napisane przez wojtek.cfg#0349 ------
----------------- ©  2019 ------------------
--------------------------------------------

-- LEPIEJ NIE DOTYKAJ -- CHYBA ŻE WIESZ CO ROBISZ --


ESX 					= nil



TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('wojtek_hotdogi:hajs')
AddEventHandler('wojtek_hotdogi:hajs', function()

	-- Definicje hajsu
	local h1 = Config.Wyplata1
	local h2 = Config.Wyplata2
	local ht = Config.Wyplatanielosuj
	local h3 = math.random(h1,h2)
	--
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)


	if Config.losujwyplate == true then
	xPlayer.addMoney(h3)
	TriggerClientEvent('esx:showNotification', source, 'Zarobiłeś ~g~'..h3..' $')
	else
	xPlayer.addMoney(ht)
	TriggerClientEvent('esx:showNotification', source, 'Zarobiłeś ~g~'..ht..' $')
	end

end)



--------------------------------------------
------ Napisane przez wojtek.cfg#0349 ------
----------------- ©  2019 ------------------
--------------------------------------------