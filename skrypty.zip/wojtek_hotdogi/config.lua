--------------------------------------------
------ Napisane przez wojtek.cfg#0349 ------
----------------- ©  2019 ------------------
--------------------------------------------


Config                         = {}


Config.czasanimacji            = 3 -- 3 sekund, czas animacji pracy

Config.dodatkowebudki          = true -- dodatkowe budki niedaleko garażu głównego (więcej info w ogłoszeniu na dc!)


Config.potrzebnapraca          = false -- czy gracz potrzebuje pracy "hotdog" aby widzieć blipy i pracować

-- BLIPY --
Config.blipyoff               = false -- Zmień na true -- jeżeli ikonki na mapie nie mają nigdy być wyśiwtlane 
Config.ikonka                 = 80 -- rodzaj ikonki na mapie -- (dostępne rodzaje: https://wiki.gtanet.work/index.php?title=Blips)
Config.kolorikonki            = 2   -- kolor ikonki na mapie -- (dostępne kolory: https://wiki.gtanet.work/index.php?title=Blips)
Config.wielkoscikonki         = 0.5 -- wielkość ikonki na mapie -- standardowo 0.5


-- Wypłaty, pieniążki, itp. --
Config.losujwyplate       = true -- true wypłata będzie losowana z wartości Config.Wypłata1 - Config.Wypłata2 // false - gracz będzie otrzymywał stałą wypłatę zdefiniowaną w Config.Wyplatanielosuj

-- Jeśli gracz ma otrzymywać stały zarobek --
Config.Wyplatanielosuj    = 50

-- Jeśli chcesz losować zarobek --
Config.Wyplata1					  = 150 -- najmniejsza zapłata
Config.Wyplata2 				  = 350 -- największa zapłata




Config.strefastandardowebudki = {  
  
  budka1 = {
   Pos   = { x = -1719.86, y = -1104.20, z = 12.1 },
   Size  = { x = 1.5, y = 1.5, z = 1.0 },
   Color = { r = 100, g = 255, b = 0 },  
   Type  = 25,
 },
 
  budka2 = {
   Pos   = { x = -1771.98, y = -1161.04, z = 12.1 },
   Size  = { x = 1.5, y = 1.5, z = 1.0 },
   Color = { r = 100, g = 255, b = 0 },   
   Type  = 25,
 },
 
 
}

Config.strefadodatkowebudki = {

  budka3 = {
    Pos   = { x = 232.51, y = -901.48, z = 29.7 },
    Size  = { x = 1.5, y = 1.5, z = 1.0 },
    Color = { r = 100, g = 255, b = 0 },  
    Type  = 25, 
  },

  budka4 = {
    Pos   = { x = 230.29, y = -904.86, z = 29.7 },
    Size  = { x = 1.5, y = 1.5, z = 1.0 },
    Color = { r = 100, g = 255, b = 0 },  
    Type  = 25, 
  },
  
}


--------------------------------------------
------ Napisane przez wojtek.cfg#0349 ------
----------------- ©  2019 ------------------
--------------------------------------------