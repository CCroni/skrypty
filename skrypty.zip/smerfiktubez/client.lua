ESX                           = nil
Citizen.CreateThread(function()

	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

end)
function ShowAdvancedNotification(title, subject, msg, icon, iconType)


	SetNotificationTextEntry('STRING')
	AddTextComponentString(msg)
	SetNotificationMessage(icon, icon, false, iconType, title, subject)
	DrawNotification(false, false)

end


RegisterNetEvent('smerfik:tak')
AddEventHandler('smerfik:tak', function(id, imie, data, dodatek)

  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  local mugshot, mugshotStr = ESX.Game.GetPedMugshot(GetPlayerPed(pid))
  local ikonka = CHAR_AMMUNATION
  if pid == myId then
ShowAdvancedNotification(imie, data, dodatek, 'CHAR_LS_CUSTOMS', 9)

  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 19.999 then
 ShowAdvancedNotification(imie, data, dodatek, 'CHAR_LS_CUSTOMS', 9)

  end
  
  UnregisterPedheadshot(mugshot)

end)





