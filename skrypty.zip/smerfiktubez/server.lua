ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
local katb = false
local jestb = 'nil'
function getUbezpieczenie(source, rejestracja)
	local identifier = GetPlayerIdentifiers(source)[1]

local result = MySQL.Sync.fetchAll("SELECT * FROM smerfik_ubezpieczenia WHERE rejestracja = @rejestracja",
    {
      ['@rejestracja']   = rejestracja
    })


	if result[1] ~= nil then

katb = true

jestb = '~h~~g~Tak ~s~'

	else


		jestb = '~h~~r~Nie ~s~'
	end
end

TriggerEvent('es:addGroupCommand', 'ubezpieczenie', 'user', function(source, arg, user)
local _source = source
local sourceXPlayer = ESX.GetPlayerFromId(_source)
if sourceXPlayer.job.name == 'mecano' or sourceXPlayer.job.name == 'police' then
        local ubezpieczonko = getUbezpieczenie(source, arg[1])
		TriggerClientEvent('smerfik:tak', -1, source, '~h~Baza danych', '~s~Los Santos Customs ', '~h~Ubezpieczenie: '..jestb)
else
print('Nie masz dostepu do bazy danych Los Santos Customs')
end
end, function(source, args, user)
	TriggerClientEvent('chat:addMessage', source, { args = { '^1SYSTEM', 'To nie dla Ciebie.' } })
end, {help = "Ubezpiecz auto"})

RegisterNetEvent('smerfik:naza')
AddEventHandler('smerfik:naza', function(player)
TriggerClientEvent('smerfik:tak', -1, source, '~h~Baza danych', '~s~Los Santos Customs ', '~h~Ubezpieczono auto o rejestracji: ~y~'.. player)
giveUbezpieczenie(player)

end)

TriggerEvent('es:addGroupCommand', 'ubezpiecz', 'user', function(source, arg, user)
local _source = source
local sourceXPlayer = ESX.GetPlayerFromId(_source)
if sourceXPlayer.job.name == 'mecano' then
	if sourceXPlayer.job.grade == 3 or sourceXPlayer.job.grade == 4 or sourceXPlayer.job.grade == 5 or sourceXPlayer.job.grade == 6 or sourceXPlayer.job.grade == 7 then
	local x = tonumber(arg[1])
	
	TriggerEvent('smerfik:naza', arg[1])
	else
	print('Ta komenda jest przeznaczona dla mechanikow z wyzszym stopniem')
	end
else
print('Jest to komenda przeznaczona tylko dla mechanika')
end
end, function(source, args, user)
	TriggerClientEvent('chat:addMessage', source, { args = { '^1SYSTEM', 'To nie dla Ciebie.' } })
end, {help = "Ubezpiecz auto"})

function giveUbezpieczenie(target)


print(rejestracja)
	MySQL.Async.execute('INSERT INTO smerfik_ubezpieczenia (rejestracja, ubezpieczone) VALUES (@rejestracja, @ubezpieczone)',
	{
		['@rejestracja']   = target,
		['@ubezpieczone']   = 1
	}, function (rowsChanged)
				if cb ~= nil then
				cb()
			end
	end)
end














