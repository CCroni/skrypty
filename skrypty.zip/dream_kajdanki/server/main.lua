ESX = nil
--Tościk#9715
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
---
RegisterServerEvent('tostKajdany:PlayWithinDistance')
AddEventHandler('tostKajdany:PlayWithinDistance', function(maxDistance, soundFile, soundVolume)
    TriggerClientEvent('tostKajdany2:PlayWithinDistance', -1, source, maxDistance, soundFile, soundVolume)
end)
---
RegisterServerEvent('tostKajdany:confiscatePlayerItem')
AddEventHandler('tostKajdany:confiscatePlayerItem', function(target, itemType, itemName, amount)
	local _source = source
	local sourceXPlayer = ESX.GetPlayerFromId(_source)
	local targetXPlayer = ESX.GetPlayerFromId(target)

	if itemType == 'item_standard' then
		local targetItem = targetXPlayer.getInventoryItem(itemName)
		local sourceItem = sourceXPlayer.getInventoryItem(itemName)

		if targetItem.count > 0 and targetItem.count <= amount then
		
			if sourceItem.limit ~= -1 and (sourceItem.count + amount) > sourceItem.limit then
				TriggerClientEvent('esx:showNotification', _source, '~y~Nieprawidłowa ilość')
			else
				targetXPlayer.removeInventoryItem(itemName, amount)
				sourceXPlayer.addInventoryItem   (itemName, amount)
				TriggerClientEvent('esx:showNotification', _source, 'Skonfiskowałeś ~g~'..sourceItem.label.. '~w~ w ilości ~g~'..amount.. '~w~ osobie ~g~'..target)
				TriggerClientEvent('esx:showNotification', target,  'Zabrano ci ~g~'..sourceItem.label..'~w~ w ilości ~g~'..amount.. '~w~ przez ~g~' .._source)
			end
		else
			TriggerClientEvent('esx:showNotification', _source, '~y~Nieprawidłowa ilość')
		end

	elseif itemType == 'item_account' then
		targetXPlayer.removeAccountMoney(itemName, amount)
		sourceXPlayer.addAccountMoney   (itemName, amount)
		TriggerClientEvent('esx:showNotification', _source, 'Skonfiskowałeś ~g~'..itemName.. '~w~ w ilości ~g~'..amount.. '~w~ osobie ~g~'..target)
		TriggerClientEvent('esx:showNotification', target,  'Zabrano ci ~g~'..itemName.. '~w~ w ilości ~g~'..amount..'~w~ przez ~g~'.._source)

	elseif itemType == 'item_weapon' then
		if amount == nil then amount = 0 end
		targetXPlayer.removeWeapon(itemName, amount)
		sourceXPlayer.addWeapon   (itemName, amount)
		TriggerClientEvent('esx:showNotification', target, 'Skonfiskowano ci broń ~g~'..ESX.GetWeaponLabel(itemName).. '~w~ z amunicją ~g~'..amount.. '~w~ przez ~g~'.._source)
		TriggerClientEvent('esx:showNotification', _source,  'Skonfiskowałeś ~g~'..ESX.GetWeaponLabel(itemName).. '~w~ z amunicją ~g~' ..amount.. '~w~ osobie ~g~'..target)
	end
end)

RegisterServerEvent('tostKajdany:handcuff')
AddEventHandler('tostKajdany:handcuff', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)
		TriggerClientEvent('tostKajdany:handcuff', target)
		TriggerClientEvent('esx:showNotification', target,  '~r~Zostałeś zakuty/rozkuty przez: '..source)
		TriggerClientEvent('esx:showNotification', source,  '~y~Zakuwasz/Rozkuwasz: '..target)
end)

RegisterServerEvent('tostKajdany:drag')
AddEventHandler('tostKajdany:drag', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	TriggerClientEvent('tostKajdany:drag', target, source)

end)

RegisterServerEvent('tostKajdany:putInVehicle')
AddEventHandler('tostKajdany:putInVehicle', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	TriggerClientEvent('tostKajdany:putInVehicle', target)
end)

RegisterServerEvent('tostKajdany:OutVehicle')
AddEventHandler('tostKajdany:OutVehicle', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)

	TriggerClientEvent('tostKajdany:OutVehicle', target)
end)

ESX.RegisterServerCallback('tostKajdany:getOtherPlayerData', function(source, cb, target)

	if Config.EnableESXIdentity then

		local xPlayer = ESX.GetPlayerFromId(target)

		local result = MySQL.Sync.fetchAll('SELECT firstname, lastname, sex, dateofbirth, height FROM users WHERE identifier = @identifier', {
			['@identifier'] = xPlayer.identifier
		})

		local firstname = result[1].firstname
		local lastname  = result[1].lastname
		local sex       = result[1].sex
		local dob       = result[1].dateofbirth
		local height    = result[1].height

		local data = {
			name      = GetPlayerName(target),
			job       = xPlayer.job,
			inventory = xPlayer.inventory,
			accounts  = xPlayer.accounts,
			weapons   = xPlayer.loadout,
			firstname = firstname,
			lastname  = lastname,
			sex       = sex,
			dob       = dob,
			height    = height
		}

		TriggerEvent('esx_status:getStatus', target, 'drunk', function(status)
			if status ~= nil then
				data.drunk = math.floor(status.percent)
			end
		end)

		if Config.EnableLicenses then
			TriggerEvent('esx_license:getLicenses', target, function(licenses)
				data.licenses = licenses
				cb(data)
			end)
		else
			cb(data)
		end

	else

		local xPlayer = ESX.GetPlayerFromId(target)

		local data = {
			name       = GetPlayerName(target),
			job        = xPlayer.job,
			inventory  = xPlayer.inventory,
			accounts   = xPlayer.accounts,
			weapons    = xPlayer.loadout
		}

		TriggerEvent('esx_status:getStatus', target, 'drunk', function(status)
			if status ~= nil then
				data.drunk = math.floor(status.percent)
			end
		end)

		TriggerEvent('esx_license:getLicenses', target, function(licenses)
			data.licenses = licenses
		end)

		cb(data)

	end

end)

ESX.RegisterServerCallback('tostKajdany:getPlayerInventory', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	local items   = xPlayer.inventory

	cb( { items = items } )
end)

ESX.RegisterUsableItem('kaje', function(source)
	TriggerClientEvent('tostKajdany:MenuKajdanek', source)
	Wait(2000)
end)