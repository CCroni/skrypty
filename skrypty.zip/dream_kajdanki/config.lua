Config                            = {}
Config.EnableESXIdentity          = true 
Config.EnableHandcuffTimer        = true 
Config.HandcuffTimer              = 10 * 60000 -- 10 min
