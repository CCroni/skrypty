Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.GangStations = {

  Gang = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 60,
      Display = 4,
      Scale   = 1.2,
      Colour  = 29,
    },

    AuthorizedWeapons = {
        { name = 'WEAPON_COMBATPISTOL',     price = 50000 },
    },

	  AuthorizedVehicles = {
		  { name = 'schafter5',  label = 'Véhicule Civil' },
		  { name = 'Akuma',    label = 'Moto' },
		  { name = 'Granger',   label = '4X4' },
		  { name = 'mule3',      label = 'Camion de Transport' },
	  },

    Cloakrooms = {
      { x = 1400.6047363282, y = 1159.6046142578, z = 114.33366394042},
    },

    Armories = {
      { x = 1398.3659667968, y = 1156.9549560546, z = 114.33366394042},
    },

    Vehicles = {
      {
        Spawner    = { x = 120.57460021973, y = -2196.5703125, z = 5.0333256721497 },
        SpawnPoint = { x = 126.54863739014, y = -2192.8732910156, z = 5.0333247184753 },
        Heading    = 261.51,
      }
    },

    VehicleDeleters = {
      { x = 126.88283538818, y = -2199.6921386719, z = 5.0333247184753 },
      
    },

    BossActions = {
      { x = 1397.4569091796, y = 1164.0841064454, z = 114.33366394042 },
    },

  },

}
