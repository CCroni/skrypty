# BY @RUSKI#0001 ON DISCORD

## INFORMATION ##
# Do not sell this script or claim it to be yours
# This script is depricated please dont ask me for help 

## SOUND ##
# I've added a 2200ms timig interaval which works well to accomodate the sound effect that may be implemented via InteractSound
# To add it use the file name "cuffseffect.ogg" add it to your 'InteractSound' and its resource.

# Streamable: "https://streamable.com/fx7q3" (you maqy change the keys that start the anim)

## CONTROLS ##
# OTWÓRZ MENU =     LewyShift + NumPad6

#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

## Installation
1. Move `esx_ruskiarrest` into Resources.
2. Add to Server.cfg.
3. Modify to your own preference (or dont)
4. Run
