$(function () {
  //$('.container-fluid').css('display', 'none');
  //$('.container-fluid').css('display', 'block');
  $(document).keyup(function (e) {
    if (e.keyCode == 27) {
      $(".container-fluid").fadeOut();
      $.post("http://smerfikmenu/zamknij", JSON.stringify({}));
    }
  });
  $(document).ready(function () {
    window.addEventListener("message", function (event) {
      var item = event.data;

      if (item.dzialaj == true) {
        $(".container-fluid").css("display", "block");
      } else if (item.dzialaj == false) {
        $(".container-fluid").css("display", "none");
      }
    });

    $("#1").click(function () {
      setTimeout(function () {
        $.post("http://smerfikmenu/telefon", JSON.stringify({}));
        $.post("http://smerfikmenu/zamknij", JSON.stringify({}));
      }, 1);
    });
    $("#2").click(function () {
      setTimeout(function () {
        $.post("http://smerfikmenu/zamknij", JSON.stringify({}));
        $.post("http://smerfikmenu/ekwipunek", JSON.stringify({}));
      }, 1);
    });
        $("#3").click(function () {
      setTimeout(function () {
        $.post("http://smerfikmenu/dowod", JSON.stringify({}));
        $.post("http://smerfikmenu/zamknij", JSON.stringify({}));
      }, 1);
    });
        $("#4").click(function () {
      setTimeout(function () {
        $.post("http://smerfikmenu/wizytowka", JSON.stringify({}));
        $.post("http://smerfikmenu/zamknij", JSON.stringify({}));
      }, 1);
    });

    $("#9").click(function () {
      $.post("http://smerfikmenu/zamknij", JSON.stringify({}));
    });
  });
});