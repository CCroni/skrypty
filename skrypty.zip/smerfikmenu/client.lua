local PlayerData = {}
ESX = nil

Citizen.CreateThread(function()
while ESX == nil do
  TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
  Citizen.Wait(0)
end
end)
Citizen.CreateThread(function()
while true do
  Citizen.Wait(1)
  if IsControlJustReleased(0, 246) then
    TriggerServerEvent('takedata:smerfikmenu', source)
  end
end
end)
RegisterNetEvent('smerfimenu:open')
AddEventHandler('smerfimenu:open', function(money, bank)

    SetNuiFocus( true, true )
    SendNUIMessage({
      dzialaj = true
    })

end)
RegisterCommand('testujmenugosciu', function()
  TriggerServerEvent('takedata:smerfikmenu', source)
end, false)
RegisterNUICallback('telefon', function(data, cb) 
  TriggerServerEvent('smerfikmenu:telefon')
end)

RegisterNUICallback('dowod', function(data, cb) 
  TriggerServerEvent('esx_dowod:pokaz', GetPlayerServerId(PlayerId()))	
end)

RegisterNUICallback('wizytowka', function(data, cb) 
  TriggerServerEvent('esx_dowod:wizytowka', GetPlayerServerId(PlayerId()))	
end)
RegisterNUICallback('ekwipunek', function(data, cb)  
  ESX.ShowInventory()
end)

RegisterNUICallback('zamknij', function(data, cb)
  SetNuiFocus( false )
  SendNUIMessage({
    dzialaj = false
  })
end)