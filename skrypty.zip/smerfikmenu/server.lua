ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('takedata:smerfikmenu')
AddEventHandler('takedata:smerfikmenu', function()
	local _source  = source
	local xPlayer  = ESX.GetPlayerFromId(_source)



local mon = xPlayer.getMoney()
local ban = xPlayer.getBank()
TriggerClientEvent('smerfimenu:open', source, mon, ban)
end)

RegisterServerEvent('smerfikmenu:telefon')
AddEventHandler('smerfikmenu:telefon', function()

	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local ilosc = xPlayer.getInventoryItem("phone").count
	
	if ilosc <= 0 then
		TriggerClientEvent("esx:showNotification", _source, "~r~Nie posiadasz telefonu!")
	else
		TriggerClientEvent("gcPhone:closeopenPhone", source)
	end

end)
