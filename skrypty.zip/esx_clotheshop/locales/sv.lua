Locales['sv'] = {
	['valid_this_purchase'] = 'vill du köpa dessa kläder?',
	['yes'] = 'ja',
	['no'] = 'nej',
	['not_enough_money'] = 'du har ~r~inte råd~s~ för att köpa detta',
	['press_menu'] = 'tryck ~INPUT_CONTEXT~ för att komma åt menyn',
	['clothes'] = 'kläder',
	['you_paid'] = 'du har betalat ~g~$%s~s~',
	['save_in_dressing'] = 'vill du spara outfiten i din fastighet?',
	['name_outfit'] = 'vad ska din outfit heta?',
	['saved_outfit'] = 'outfit har sparats!',
}