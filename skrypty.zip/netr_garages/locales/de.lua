Locales['de'] = {

	['veh_released'] = 'Fahrzeug ~g~genommen',
	['veh_stored'] = 'vehicle ~g~geparkt',

}
