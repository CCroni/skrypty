Locales['fr'] = {

	['veh_released'] = 'véhicule ~g~sorti',
	['veh_stored'] = 'véhicule ~g~rangé',

}
