Locales['br'] = {

	['veh_released'] = 'Veículo ~g~já está disponivel',
	['veh_stored'] = 'Veículo ~g~guardado',

}
