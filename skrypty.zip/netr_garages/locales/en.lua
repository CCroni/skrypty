Locales['en'] = {

	['veh_released'] = 'Pojazd ~g~wyciągnięty',
	['veh_stored'] = 'Pojazd ~g~schowany',

}
