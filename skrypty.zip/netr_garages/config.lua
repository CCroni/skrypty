Config                      = {}
Config.DrawDistance         = 100.0
Config.MenuDistance         = 3.0
Config.MarkerType           = 25
Config.MarkerSize           = {x = 5.0, y = 5.0, z = 1.0}
Config.MarkerColor          = {r = 255, g = 255, b = 255}
Config.ParkingMarkerSize    = {x = 5.0, y = 5.0, z = 2.0}
Config.ParkingMarkerColor   = {r = 102, g = 102, b = 204}
Config.ZDiff                = 0.5
Config.MinimumHealthPercent = 0

Config.Locale = 'en'

Config.Zones = {}

Config.Garages = {

  Pierdl = {
		Marker 	= { x = 1870.100, y = 2647.100, z = 44.680},
		Size  	= { x = 1.5, y = 1.5, z = 1.0 },
	},
  Plaza = {
		Marker 	= { x = -1665.100, y = -889.100, z = 7.660},
		Size  	= { x = 1.5, y = 1.5, z = 1.0 },
	},
  Drwal = {
		Marker 	= { x = -838.001, y = 5410.001, z = 33.600},
		Size  	= { x = 1.5, y = 1.5, z = 1.0 },
	},
  MiltonDrive = {
		Marker 	= { x = -796.542, y = 318.137, z = 84.700},
		Size  	= { x = 1.5, y = 1.5, z = 1.0 },
	},
  Square = {
		Marker 	= { x = 235.01, y = -784.24, z = 29.690},
		Size  	= { x = 1.5, y = 1.5, z = 1.0 },
	},
  SandyShores = {
		Marker 	= { x = 1467.12, y = 3740.12, z = 32.60},
		Size  	= { x = 1.5, y = 1.5, z = 1.0 },
	},
  PaletoBay = {
		Marker 	= { x = 10.16, y = 6332.0, z = 30.26},
		Size  	= { x = 1.5, y = 1.5, z = 1.0 },
	},
  Main = {
		Marker 	= { x = 44.2, y = -858.36, z = 29.74},
		Size  	= { x = 1.5, y = 1.5, z = 1.0 },
	},
}

Config.Impound = {
  I1 = {
		Marker 	= { x = 406.38, y = -1631.68, z = 28.34},
		Size  	= { x = 1.5, y = 1.5, z = 1.0 },
  },
}