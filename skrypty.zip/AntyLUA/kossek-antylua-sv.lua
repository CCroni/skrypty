ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent("kossek-antylua:kick")
AddEventHandler("kossek-antylua:kick", function()
	local xPlayer = ESX.GetPlayerFromId(source)
	print(('KOSSEK ANTYLUA | Wykryto lua executora'):format(xPlayer.identifier))
	DropPlayer(source, "KOSSEK ANTYLUA | Wykryto lua executora")
end)