description 'kossek-antylua'

client_scripts {
    'kossek-antylua-cl.lua'
}
server_scripts {
    'kossek-antylua-sv.lua'
}
