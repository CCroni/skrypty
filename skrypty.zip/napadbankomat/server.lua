--Written by Tościk#9715

ESX = nil

TriggerEvent('esx:getSharedObject', function(obj)
	ESX = obj
end)

RegisterServerEvent('tost:zgarnijsiano')
AddEventHandler('tost:zgarnijsiano', function()
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local Ilosc = math.random(3500,7500) --Mozna zgarnac od 500 do max 1800$ za kase fiskalna
	TriggerClientEvent('esx:showNotification', source, '~y~Zabierasz ~g~'..Ilosc..'$~y~ z bankomatu.')
	TriggerClientEvent('esx:showNotification', source, '~y~Następną kasę możesz obrabować za 180 sekund.')
    xPlayer.addMoney(Ilosc)
	Wait(500)
end)


RegisterServerEvent('tost:zawiadompsy')
AddEventHandler('tost:zawiadompsy', function(x, y, z) 
    TriggerClientEvent('tost:infodlalspd', -1, x, y, z)
end)