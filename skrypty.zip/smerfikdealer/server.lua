ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


RegisterServerEvent('sell:weed2')
AddEventHandler('sell:weed2', function(x)
    local sc = math.random(1,5)
local xPlayer = ESX.GetPlayerFromId(source)
local ilosc = xPlayer.getInventoryItem('weed').count
if ilosc >= sc then
xPlayer.removeInventoryItem('weed', sc)
TriggerClientEvent('esx:showNotification', source, 'Klient kupił od Ciebie ' .. sc .. ' sztuk weedu')

else
    TriggerClientEvent('esx:showNotification', source, 'Towar wysypał Ci się, nie dostajesz pieniedzy!')
end
end)
ESX.RegisterServerCallback('weed:check1', function(source, cb)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
 ils1 = xPlayer.getInventoryItem('weed').count
	cb(ils1)
end)