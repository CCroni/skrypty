local Keys = {
	["ESC"] = 322, ["BACKSPACE"] = 177, ["E"] = 38, ["ENTER"] = 18,	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173
}

ESX                           = nil
local PlayerData                = {}
local cena = 100
local moge = false
local blipz = false
local blip = nil
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	Citizen.Wait(5000)
	PlayerData = ESX.GetPlayerData()
end)
RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	PlayerData.job = job
	
	Citizen.Wait(5000)

end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1000)
if blipz == true then
	local ko = GetEntityCoords(ped, true)
					if blip == nil then
						blip = AddBlipForCoord(ko)
						SetBlipSprite(blip, 480)
										SetBlipScale(blip, 1.0)
										SetBlipColour(blip, 70)
							BeginTextCommandSetBlipName("STRING")
						AddTextComponentString("Klient")
							EndTextCommandSetBlipName(blip)
					else
						RemoveBlip(blip)
						blip = AddBlipForCoord(ko)
						SetBlipSprite(blip, 480)
										SetBlipScale(blip, 1.0)
										SetBlipColour(blip, 70)
							BeginTextCommandSetBlipName("STRING")
						AddTextComponentString("Klient")
							EndTextCommandSetBlipName(blip)
					end
	end

end
end)
RegisterCommand('dealer', function()

	ESX.TriggerServerCallback('weed:check1', function(ils1)

	if ils1 >= 4 then

		if moge == true then
		ESX.ShowNotification('Musisz odczekać zanim znowu sprawdzisz, czy nie ma kupujących!')
		else

		dealer()
		end

else
ESX.ShowNotification('Musisz mieć przynajmniej 4 weedu!')
end
end)
end, false)

function dealer()
moge = true
local szn = math.random(1,10)
if szn >= 10 then
	ESX.ShowNotification('Wyszukiwanie kupujących w okolicy!')
	local szansa = math.random(1,4)
	if szansa == 1 then
		modelpeda = "csb_car3guy1"
		end
		if szansa == 3 then
			modelpeda = "csb_porndudes"
		end
		if szansa == 4 then
			modelpeda = "a_m_m_soucent_02"
		end
		if szansa == 2 then
			modelpeda = "a_m_m_tennis_01"
		end
    RequestModel(GetHashKey(modelpeda))
    while not HasModelLoaded(GetHashKey(modelpeda)) do
      Wait(155)
    end
	local coords = GetEntityCoords(PlayerPedId(), true)
	local coords2 = vector3(math.random(-8000, 8000), math.random(-8000, 8000), coords.z)
	wysz = true
	while GetDistanceBetweenCoords(coords, coords2, false) > 100 do
		Citizen.Wait(0)
	 coords2 = vector3(math.random(-3500, 4000), math.random(-3300, 7000), coords.z)
	end
	wysz = false
	ESX.ShowNotification('Kupujący znaleziony, idzie na twoje współrzędne! Oznaczono go na mapie')

 ped =  CreatePed(4, GetHashKey(modelpeda),coords2, 0.404, false, true)
	  SetEntityInvincible(ped, true)
	  TaskPedSlideToCoord(ped, coords, 0.0, true)
	  blipz = true
	  SetBlockingOfNonTemporaryEvents(ped, true)
	  pedcord = GetEntityCoords(ped, true)

		while GetDistanceBetweenCoords(coords, pedcord, false) > 5 do
		Citizen.Wait(5)
			pedcord = GetEntityCoords(ped, true)
		end
	
	
		pedcord = GetEntityCoords(ped, true)
		local coords5 = GetEntityCoords(PlayerPedId(), true)
		Citizen.Wait(2000)
		blipz = false
		RemoveBlip(blip)
		blip = nil
		
		if GetDistanceBetweenCoords(coords5, pedcord, true) <= 8 then
			local il = math.random(1,5)
			ESX.ShowNotification('Klient kupuje dragi, czekaj!')
			Citizen.Wait(2000)
			RemoveBlip(blip)
			anim()

			ESX.ShowNotification('Zarobiłeś ~g~' .. il * cena .. '$')
			TriggerServerEvent('sell:weed2', source, il)
			TaskPedSlideToCoord(ped, coords2, 0.0, true)
			Citizen.Wait(30000)
			moge = false
			DeleteEntity(ped)
		else
			ESX.ShowNotification('Odszedłeś za daleko, tracisz klienta')
			TaskPedSlideToCoord(ped, coords2, 0.0, true)
			Citizen.Wait(30000)
			moge = false
			DeleteEntity(ped)
		end
	else
		ESX.ShowNotification('Nie ma w okolicy nikogo chętnego, spróbuj jeszcze raz za 30 sekund')
		Citizen.Wait(30000)
		moge = false
	end
end
function anim()

	weed_bottle = CreateObject(GetHashKey('prop_weed_bottle'), 0, 0, 0, true)
	AttachEntityToEntity(weed_bottle, PlayerPedId(), GetPedBoneIndex(PlayerPedId(),  57005), 0.13, 0.02, 0.0, -90.0, 0, 0, 1, 1, 0, 1, 0, 1)
	RequestAnimDict('weapon@w_sp_jerrycan')
	while not HasAnimDictLoaded("weapon@w_sp_jerrycan") do
		Citizen.Wait(10)
	end
	TaskPlayAnim(PlayerPedId(), 'weapon@w_sp_jerrycan', 'unholster', 8.0, 8.0, -1, 0, 0, false, false, false)
Citizen.Wait(1000)
	RequestAnimDict('mp_common')
	while not HasAnimDictLoaded("mp_common") do
		Citizen.Wait(10)
	end
	TaskPlayAnim(PlayerPedId(), 'mp_common', 'givetake1_a', 8.0, 8.0, -1, 0, 0, false, false, false)
	TaskPlayAnim(ped, 'mp_common', 'givetake1_b', 8.0, 8.0, -1, 0, 0, false, false, false)
	Wait(1000)
	AttachEntityToEntity(weed_bottle, ped, GetPedBoneIndex(PlayerPedId(),  60309), 0.0, 0.0, 0.0, 0.0, 0.0, 90.0, 1, 1, 0, 1, 0, 1)
	Wait(1000)
	RequestAnimDict('weapon@w_sp_jerrycan')
	while not HasAnimDictLoaded("weapon@w_sp_jerrycan") do
		Citizen.Wait(10)
	end
	TaskPlayAnim(ped, 'weapon@w_sp_jerrycan', 'holster', 8.0, 8.0, -1, 0, 0, false, false, false)
	Wait(300)
	DeleteEntity(weed_bottle)
	Citizen.Wait(1000)
	cash_pile = CreateObject(GetHashKey('prop_anim_cash_pile_01'), 0, 0, 0, true)
	AttachEntityToEntity(cash_pile, ped, GetPedBoneIndex(PlayerPedId(),  60309), 0.0, 0.0, 0.0, -90.0, 0, 0, 1, 1, 0, 1, 0, 1)
	RequestAnimDict('mp_common')
	while not HasAnimDictLoaded("mp_common") do
		Citizen.Wait(10)
	end
	TaskPlayAnim(ped, 'weapon@w_sp_jerrycan', 'unholster', 8.0, 8.0, -1, 0, 0, false, false, false)
	Wait(500)
	TaskPlayAnim(ped, 'mp_common', 'givetake1_a', 8.0, 8.0, -1, 0, 0, false, false, false)
	TaskPlayAnim(PlayerPedId(), 'mp_common', 'givetake1_b', 8.0, 8.0, -1, 0, 0, false, false, false)
	Wait(1000)
	AttachEntityToEntity(cash_pile, PlayerPedId(), GetPedBoneIndex(PlayerPedId(),  57005), 0.1, 0.03, 0.0, 0.0, 0.0, 90.0, 1, 1, 0, 1, 0, 1)
	Wait(1000)
	RequestAnimDict('weapon@w_sp_jerrycan')
	while not HasAnimDictLoaded("weapon@w_sp_jerrycan") do
		Citizen.Wait(10)
	end
	TaskPlayAnim(PlayerPedId(), 'weapon@w_sp_jerrycan', 'holster', 8.0, 8.0, -1, 0, 0, false, false, false)
	Wait(300)
	DeleteEntity(cash_pile)
end

-- WYSZ
local UI = { 

	x =  0.000 ,	-- Base Screen Coords 	+ 	 x
	y = -0.001 ,	-- Base Screen Coords 	+ 	-y

}
local krop = '.'
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
if wysz == true then
	draweTxt(UI.x + 0.9405, UI.y + 0.502, 1.0,0.98,0.5, "~w~[~g~Wyszukiwanie kupującego~w~]~w~  ".. krop .. "", 255, 255, 255, 255)
	end
end
end)
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(800)
		if wysz == true then
			if krop == '...' then
				krop = '.'
			else
				krop = krop .. '.'
			end
		end
	end
end)

function draweTxt(x,y ,width,height,scale, text, r,g,b,a)
	SetTextFont(4)
	SetTextProportional(0)
	SetTextScale(scale, scale)
	SetTextColour(r, g, b, a)
	SetTextDropShadow(0, 0, 0, 0,255)
	SetTextEdge(2, 0, 0, 0, 255)
	SetTextDropShadow()
	SetTextOutline()
	SetTextEntry("STRING")
	AddTextComponentString(text)
	DrawText(x - width/2, y - height/2 + 0.005)
end