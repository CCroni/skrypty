ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
local katb = false
local jestb = 'nil'
local jesta = 'nil'
function getDane(source)

	local result = MySQL.Sync.fetchAll("SELECT * FROM users WHERE identifier = @identifier", {['@identifier'] = source})
	if result[1] ~= nil then
		local identity = result[1]

		return {
			identifier = identity['identifier'],
			job = identity['job'],
			job_grade = identity['job_grade'],
			firstname = identity['firstname'],
			lastname = identity['lastname'],
			name = identity['name'],
			dateofbirth = identity['dateofbirth'],
			odznaka = identity['odznaka']

		}
	else
		return nil
	end
end
function getCzyn(source)

	local result = MySQL.Sync.fetchAll("SELECT * FROM smerfik_baza WHERE obywatel = @obywatel", {['@obywatel'] = source})
	if result[1] ~= nil then
		local identity = result[1]

		return {
			czyn = identity['czyn']

		}
	
	else
		return nil
	end
end
 
	
function getInfo(source, player)


local result = MySQL.Sync.fetchAll("SELECT * FROM smerfik_baza WHERE obywatel = @obywatel",
    {
      ['@obywatel'] = player
    })


	if result[1] ~= nil then

katb = true

jestb = '~h~~g~Tak ~s~'

	else


		jestb = '~h~~r~Nie ~s~'
	end
	local resultz = getCzyn(player)
	local czyn = resultz.czyn
	local czynz = tonumber(czyn)

	if czyn == 1 then


		jesta = '~h~~g~Tak ~s~'
		
	elseif czyn == 0 then
		
		
				jesta = '~h~~r~Nie ~s~'
	else 
		jesta = '~h~~r~Nie ~s~'
			end
end

TriggerEvent('es:addGroupCommand', 'bazalspd', 'user', function(source, arg, user)
local _source = source
local sourceXPlayer = ESX.GetPlayerFromId(_source)
local targetXPlayer = ESX.GetPlayerFromId(arg[1])
if targetXPlayer == nil then
	print('Nie ma tekiego gracza')
	return
end
if sourceXPlayer.job.name == 'police' then
				local ubezpieczonko = getInfo(_source, targetXPlayer.identifier)
				local result = getDane(targetXPlayer.identifier)
				
		TriggerClientEvent('smerfik:takz', -1, source, '~h~Baza danych LSPD', '~y~' .. result.firstname ..' '.. result.lastname, '~h~Karany: '..jestb..' 					Za ciężkie przestępstwa: ' ..jesta)
else
print('Nie masz dostepu do bazy danych LSPD')
end
end, function(source, args, user)
	TriggerClientEvent('chat:addMessage', source, { args = { '^1SYSTEM', 'To nie dla Ciebie.' } })
end, {help = "Baza danych lspd"})

RegisterNetEvent('smerfik:bazalspd')
AddEventHandler('smerfik:bazalspd', function(player, czyn, imie, nazwisko)
	local czynz = tonumber(czyn)

	local targetXPlayer = ESX.GetPlayerFromId(player)


	local name = getDane(player)
if czyn == '1' then
TriggerClientEvent('smerfik:takz', -1, source, '~h~Baza danych', '~s~LSPD ', '~h~Dodano: ~y~'.. imie ..' '.. nazwisko..'					~s~~h~Ciężkie przestępstwo:~g~ Tak')
MySQL.Async.execute('DELETE FROM smerfik_baza WHERE obywatel = @obywatel', {
	['@obywatel'] = player
})
Citizen.Wait(1000)
giveBaza(player, 1)
elseif czyn == '0' then
	TriggerClientEvent('smerfik:takz', -1, source, '~h~Baza danych', '~s~LSPD ', '~h~Dodano: ~y~'.. imie ..' '.. nazwisko.. ' 					~s~~h~Ciężkie przestępstwo: ~r~Nie')
	giveBaza(player, 0)
else 
	print('2 Argument musi wynosic 0 albo 1')
	end


end)

TriggerEvent('es:addGroupCommand', 'bazadodaj', 'user', function(source, arg, user)
local _source = source
local sourceXPlayer = ESX.GetPlayerFromId(_source)
local targetXPlayer = ESX.GetPlayerFromId(arg[1])
if sourceXPlayer.job.name == 'police' then
	local gracz = targetXPlayer.identifier
	local result = getDane(gracz)
	local x = tonumber(arg[1])
	
	TriggerEvent('smerfik:bazalspd', targetXPlayer.identifier, arg[2], result.firstname, result.lastname)



else
print('Jest to komenda przeznaczona tylko dla policjanta')
end
end, function(source, args, user)
	TriggerClientEvent('chat:addMessage', source, { args = { '^1SYSTEM', 'To nie dla Ciebie.' } })
end, {help = "Dodaj do bazy danych lspd"})

function giveBaza(target, czyn)



	MySQL.Async.execute('INSERT INTO smerfik_baza (obywatel, czyn) VALUES (@obywatel, @czyn)',
	{
		['@obywatel']   = target,
		['@czyn']   = czyn
	}, function (rowsChanged)
				if cb ~= nil then
				cb()
			end
	end)
end


--[[RegisterCommand("kostka", function(source) 
    local num = math.random(1,6)
    local playerName = GetPlayerName(source)
		TriggerClientEvent("sendProximityMessageDo", -1, source, "Kostka", "Losowanie")
		Citizen.Wait(1000)
		TriggerClientEvent("sendProximityMessageDo", -1, source, "Kostka", "...")
		Citizen.Wait(1000)
		TriggerClientEvent("sendProximityMessageDo", -1, source, "Kostka", "...")
		Citizen.Wait(1000)
		if num == 1 then
		TriggerClientEvent("sendProximityMessageDo", -1, source, "Kostka", "Wylosowano 1")
     elseif num == 2 then
		TriggerClientEvent("sendProximityMessageDo", -1, source, "Kostka", "Wylosowano 2")
     elseif num == 3 then
		TriggerClientEvent("sendProximityMessageDo", -1, source, "Kostka", "Wylosowano 3")
	 elseif num == 4 then
		TriggerClientEvent("sendProximityMessageDo", -1, source, "Kostka", "Wylosowano 4")
     elseif num == 5 then
		TriggerClientEvent("sendProximityMessageDo", -1, source, "Kostka", "Wylosowano 5")
     elseif num == 6 then
		TriggerClientEvent("sendProximityMessageDo", -1, source, "Kostka", "Wylosowano 6")	 
 end
end, false)--]]











