USE `essentialmode`;

CREATE TABLE `smerfik_baza` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`obywatel` varchar(50) NOT NULL,
	`czyn` int(11) NOT NULL,

	PRIMARY KEY (`id`)
);